/*
 * MC60_BTSGPIO.h
 *
 *  Created on: 16-Oct-2019
 *      Author: admin
 */

#ifndef MC60_BTSGPIO_H_
#define MC60_BTSGPIO_H_
/*
 * MC60_STARTUP_COMMONS.h
 *
 *  Created on: 11-Oct-2019
 *      Author: Sriram
 */

//-------------------------------------------------INCLUDES-------------------------------------------
#include "MC60_GPIO.h"
#include "MC60_UART.h"
#include "MC60_delay.h"
//------------------------------------------------FUNTIONS---------------------------------------------

void initGpio();
void processIo();
bool flag  = FALSE;
bool flag1 = FALSE;
bool flag2 = FALSE;
bool flag3 = FALSE;
bool flag4 = FALSE;
bool flag5 = FALSE;
//------------------------------------------------FUNTIONS---------------------------------------------
typedef struct gpio
{
u32   input1;
u32   input2;
u32   input3;
u32   input4;
u32   input5;
u32   output1;
u32   output2;
u32   adc1;
u32   adc2;
};
struct gpio gpioData;





void initGpio()
{
     	//INPUT
	    pinMode(D9,INPUT,LOW,PINPULLSEL_DISABLE);  //PINNAME_PCM_OUT/SPI_MOSI//ADC2
		pinMode(D10,INPUT,LOW,PINPULLSEL_DISABLE); //PINNAME_SD_CMD
		pinMode(D11,INPUT,LOW,PINPULLSEL_DISABLE); //PINNAME_SD_CLK
		pinMode(D13,INPUT,LOW,PINPULLSEL_DISABLE); //PINNAME_SIM2_DATA
		pinMode(D17,INPUT,LOW,PINPULLSEL_DISABLE); //PINNAME_GPIO_1
		pinMode(D15,INPUT,LOW,PINPULLSEL_DISABLE); //PINNAME_SIM2_CLK

        //OUTPUT
	    pinMode(D19,OUTPUT,LOW,PINPULLSEL_DISABLE);//GPIO_PIN3
	    pinMode(D20,OUTPUT,LOW,PINPULLSEL_DISABLE);//GPIO_PIN4
}






void processIo()
{
	////read input/////
gpioData.input1=digitalRead(D10);
APP_DEBUG("\r\nGPIO VAL D1: %d\r\n",gpioData.input1);//PINNAME_SD_CMD

gpioData.input2=digitalRead(D11);
APP_DEBUG("\r\nGPIO VAL D2: %d\r\n",gpioData.input2);//PINNAME_SD_CLK

gpioData.input3=digitalRead(D13);
APP_DEBUG("\r\nGPIO VAL D3: %d\r\n",gpioData.input3);//PINNAME_SIM2_DATA

gpioData.input4=digitalRead(D17);
APP_DEBUG("\r\nGPIO VAL D4: %d\r\n",gpioData.input4);//PINNAME_GPIO_1

gpioData.input5=digitalRead(D15);
APP_DEBUG("\r\nGPIO VAL D5: %d\r\n",gpioData.input5);//PINNAME_SIM2_CLK,

APP_DEBUG("\r\nADC VAL 1: %d\r\n",gpioData.adc1);// ADC pin

gpioData.adc2=digitalRead(D9);
APP_DEBUG("\r\nADC VAL 2: %d\r\n",gpioData.adc2);//PINNAME_PCM_OUT/SPI_MOSI



if(gpioData.output1==1)
{
	digitalWrite(D19,HIGH);
    APP_DEBUG("\r\nD19 pin --->HIGH");
}
else
digitalWrite(D19,LOW);


if(gpioData.output2==1)
{
digitalWrite(D20,HIGH);
APP_DEBUG("\r\nD20 pin --->HIGH");
}
else
digitalWrite(D20,LOW);

delay(1000);
}

void gpio_testing(){

//	digitalWrite(D19,HIGH);//PINNAME_GPIO3
//	digitalWrite(D20,HIGH);//PINNAME_GPIO4
	if(flag == 0){
		APP_DEBUG("\r\n<---GPIO TESTING--->\r\n\r\n<---TILT TESTING--->\r\n")
		delay(4000);
		gpioData.input4=digitalRead(D17);//GPIO_1///tilt
		APP_DEBUG("\r\n<---PIN_LEVEL=%d--->\r\n",Ql_GPIO_GetLevel(D17));
		delay(4000);

	if(gpioData.input4==0 && flag1==0){

		APP_DEBUG("\r\n<---PLZ TILT THE BOARD--->\r\n\r\n<---WIT 9 SEC--->\r\n");
		delay(9000);
		gpioData.input4=digitalRead(D17);//GPIO_1///tilt
		APP_DEBUG("\r\n<---PIN_LEVEL=%d--->\r\n",Ql_GPIO_GetLevel(D17));
		flag1=1;
	}
	 if(gpioData.input4==0 && flag1==1){
		 APP_DEBUG("\r\n<---TILT TEST FAIL--->\r\n");
		 delay(4000);
	}
	 if(gpioData.input4==1 && flag1==1){
		 APP_DEBUG("\r\n<---TILT TESTING OK--->\r\n");
		 delay(9000);
		 APP_DEBUG("\r\n<---PLZ GIVE THE INPUT ON THE LDR--->\r\n");
		 gpioData.input5=digitalRead(D15);
		 delay(4000);
	}
	 if(flag1==1 && gpioData.input5 ==0 && flag2==0){
		gpioData.input5=digitalRead(D15);//PINNAME_SIM2_CLK,//tamper
		APP_DEBUG("\r\n<---PIN_LEVEL=%d--->\r\n",Ql_GPIO_GetLevel(D15));
		APP_DEBUG("\r\n<---WIT FOR 9 SEC--->\r\n",Ql_GPIO_GetLevel(D15));
		delay(9000);
		gpioData.input5=digitalRead(D15);//PINNAME_SIM2_CLK,//tamper

		APP_DEBUG("\r\n<---PIN_LEVEL=%d--->\r\n",Ql_GPIO_GetLevel(D15));

		flag2=1;
		delay(5000);
	}
	  if(flag2==1 && gpioData.input5 ==0 ){
		 APP_DEBUG("\r\n<---LDR TEST FAIL--->\r\n");
		 delay(2000);
	 }
	  if(flag2==1 && gpioData.input5 ==1 && flag3==0 ){
		 APP_DEBUG("\r\n<---PIN_LEVEL=%d--->\r\n",Ql_GPIO_GetLevel(D15));
		 APP_DEBUG("\r\n<---LDR TEST OK--->\r\n");
		 flag3=1;
		 delay(2000);
		 APP_DEBUG("\r\n<---INPUT(etc.pin) CHECKING TIMING ON PLZ CHECK MIN 10 SEC--->\r\n");
	 }
	if(flag3==1&&flag4==0){
	for(int j=0;j<=9000;j++){
	gpioData.input1=digitalRead(D10);
	APP_DEBUG("\r\nGPIO VAL D1: %d\r\n",gpioData.input1);//PINNAME_SD_CMD

	gpioData.input2=digitalRead(D11);
	APP_DEBUG("\r\nGPIO VAL D2: %d\r\n",gpioData.input2);//PINNAME_SD_CLK

	gpioData.input3=digitalRead(D13);
	APP_DEBUG("\r\nGPIO VAL D3: %d\r\n",gpioData.input3);//PINNAME_SIM2_DATA

	APP_DEBUG("\r\nADC VAL 1: %d\r\n",gpioData.adc1);// ADC pin

	gpioData.adc2=digitalRead(D9);
	APP_DEBUG("\r\nADC VAL 2: %d\r\n",gpioData.adc2);//PINNAME_PCM_OUT/SPI_MOSI

	flag4=1;
	}
	APP_DEBUG("\r\n<---OUTPUT CHECKING TIMING ON--->\r\n");//PINNAME_SD_CMD
	delay(2000);
	}
	if(flag4==1 && flag5==0){
		for(int k=0;k<5000;k++){
		digitalWrite(D19,HIGH);//PINNAME_GPIO3
		digitalWrite(D20,HIGH);//PINNAME_GPIO4
		delay(2000);
		digitalWrite(D19,LOW);//PINNAME_GPIO3
		digitalWrite(D20,LOW);//PINNAME_GPIO4
		}
		flag5=1;
		flag=1;
	}
	}
	}
void level_test(){
	APP_DEBUG("\r\n<---PIN_LEVEL D9=%d--->\r\n",Ql_GPIO_GetLevel(D9));
	APP_DEBUG("\r\n<---PIN_LEVEL D10=%d--->\r\n",Ql_GPIO_GetLevel(D10));
	APP_DEBUG("\r\n<---PIN_LEVEL D11=%d--->\r\n",Ql_GPIO_GetLevel(D11));
	APP_DEBUG("\r\n<---PIN_LEVEL D13=%d--->\r\n",Ql_GPIO_GetLevel(D13));
	APP_DEBUG("\r\n<---PIN_LEVEL D17=%d--->\r\n",Ql_GPIO_GetLevel(D17));
	APP_DEBUG("\r\n<---PIN_LEVEL D15=%d--->\r\n",Ql_GPIO_GetLevel(D15));


}

//#endif /* MC60_STARTUP_COMMONS_H_ */

//-------------------------------------------DEMO_CODE------------------------------------------------
//#ifdef __CUSTOMER_CODE__
//#include "MC60_UART.h"
//#include "MC60_ADC.h"
//#include "MC60_STARTUP_COMMONS.h"
//
//
//void adcVal()
//{
//APP_DEBUG("\r\nADC VAL 1: %d\r\n",gpioData.adc1);
//delay(1000);
//}
//
//void adcOff()
//{
//APP_DEBUG("\r\nADC off\r\n");
//}
//
//
//
//void proc_main_task(s32 taskId)
//{
//	    s8 startUpDone=0;
//	    s32 ret;
//	    ST_MSG msg;
//
//
//	    // Register & open UART port
//	    serialRegInit(UART_PORT1);
//	    serialBegin(UART_PORT1,115200);
//	    APP_DEBUG("\r\n<-- Uart 1 open -->\r\n");
//
//
//
//	    // Start message loop of this task
//	    while (1)
//	    {
//	        Ql_OS_GetMessage(&msg);
//
//	        switch(msg.message)
//	        {
//	            case MSG_ID_RIL_READY:
//	            	rilInit();
//	            	initGpio();
//	            	adcInit();
//	            	APP_DEBUG("\r\n<-- Init OK -->\r\n");
//	                break;
//
//	            case MSG_ID_USER_START:
//	            	APP_DEBUG("\r\n<-- user start -->\r\n");
//	                break;
//
//	            default:
//	            	 startUpDone=1;
//	                break;
//	    }
//}
//}
//
//void proc_subtask1(s32 taskId)
//{
//	while(TRUE)
//	{
//		APP_DEBUG("--TASHK1--\r\n");
//		processIo();
//		adcSamplingStart();
//		delay(1000);
//	}
//}
//
//#endif // __CUSTOMER_CODE__



#endif /* MC60_BTSGPIO_H_ */

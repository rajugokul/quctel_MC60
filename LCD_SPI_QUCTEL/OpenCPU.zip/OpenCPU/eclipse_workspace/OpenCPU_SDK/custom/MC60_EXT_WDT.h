
//---ZUPPA TWI INTERFACE(ZTI)---
// RATED SPEED ATMEGA328P 100kbps
// OMIT CHECKSUM FOR SMALLER CODE SIZE

#define SDA_PIN  PINNAME_RI//PINNAME_DCD
#define SCL_PIN  PINNAME_DCD

//------------------------FOR QUECTEL START FROM HERE-----------------------
// ZTI PROTOCOL SPECS
#define HEADER_1 0x7A
#define HEADER_2 0x62

enum FrameId
{
	WRITE_DATA_FRAME=0,
	READ_DATA_FRAME,
	ENTER_SLEEP_MODE,
	RESET_DEVICE_FRAME
};

enum FrameField
{
	H1=0,
	H2,
	DEVICE_ADDRESS,
	MASTER_COMMAND,
	PACKET_LENGTH_1,
	PACKET_LENGTH_2,
	PACKET_LENGTH_3,
	PACKET_LENGTH_4,
	PAYLOAD,
};

u8 chk1,chk2;

//----------CONVERSION------------
union LongToWordConv
{
	u16 dataWord[2];
	u32 dataLong;
	}ltoWConv;

//--------CROSS-PLATFORM_PORTABLE_CODES---------
void assignDataPinDirection(int direction,int pullUp)
{
Ql_GPIO_SetDirection(SDA_PIN,direction);  //INDIRECTION_IN  = 0,PINDIRECTION_OUT = 1
Ql_GPIO_SetPullSelection(SDA_PIN,pullUp); // PINPULLSEL_DISABLE  = 0,PINPULLSEL_PULLDOWN = 1,PINPULLSEL_PULLUP   = 2
}

void assignClockPinDirection(int direction,int pullUp)
{
Ql_GPIO_SetDirection(SCL_PIN,direction);  //INDIRECTION_IN  = 0,PINDIRECTION_OUT = 1
Ql_GPIO_SetPullSelection(SCL_PIN,pullUp); // PINPULLSEL_DISABLE  = 0,PINPULLSEL_PULLDOWN = 1,PINPULLSEL_PULLUP   = 2
}

int setDataPinState(int state)
{
	Ql_GPIO_SetLevel(SDA_PIN, state);
	return 1;
}

int setClockPinState(int state)
{
	Ql_GPIO_SetLevel(SCL_PIN, state);
	return 1;
}

int getDataPinState()
{
	return Ql_GPIO_GetLevel(SDA_PIN);
}

void minorDelay()
{
	Ql_Sleep(5);
}

void internalDelayMs(u16 dly)
{
	Ql_Sleep(dly);
}



//----------------------------------------------
void initializeZTIInterface()
{
	Ql_GPIO_Init(SDA_PIN, 1, 1,PINPULLSEL_PULLUP);
	Ql_GPIO_Init(SCL_PIN, 1, 1,PINPULLSEL_PULLUP);
}

void writeAByte(u8 data)
{
	volatile u8 i;
	chk1+=data;
	chk2+=chk1;
	assignDataPinDirection(1,1);
	assignClockPinDirection(1,1);
	setDataPinState(0);
	minorDelay();
    setDataPinState(1);
	minorDelay();
	setDataPinState(0);
	minorDelay();
	setDataPinState(1);
	minorDelay();
	setDataPinState(0);
	minorDelay();
	setClockPinState(0);
	minorDelay();
	//Serial.println("SEND");
    for(i=0;i<8;i++)
	{
		setDataPinState((data & (1<<i))?1:0);
		minorDelay();
		setClockPinState(1);
		minorDelay();
		setClockPinState(0);
		minorDelay();
	}
	setClockPinState(1);
	setDataPinState(1);
}

void writeFrameShort(u8 deviceAddr,u8 masterCommand,u8 *payload,u8 payloadSize)
{
	volatile u8 i;
	writeAByte(HEADER_1);
	writeAByte(HEADER_2);
	chk1=chk2=0;
	/*writeAByte(deviceAddr);
	writeAByte(masterCommand);
	writeAByte(payloadSize);
	writeAByte(0x00);
	writeAByte(0x00);
	writeAByte(0x00);*/ // DISABLE FRAME INFOMATION PROTOCOL
	/*payload[0]=1;
	payload[1]=2;
	payload[2]=3;
	payload[3]=4;*/
	for(i=0;i<4;i++)
	writeAByte(payload[i]);
	//writeAByte(chk1);
	//writeAByte(chk2);
}

u32 readDATAFromBus(u8 command,u16 sleepTime)
{
	u32 ret=0,temp=0;
	char c;
	u8 payload[4];
		payload[0]=command;
		payload[1]=sleepTime & 0x00FF;
		payload[2]=(sleepTime & 0xFF00)>>8;
		payload[3]=0;
		writeFrameShort(0x01,READ_DATA_FRAME,payload,4);
		internalDelayMs(45);
		assignDataPinDirection(0,0);
		internalDelayMs(45);
		setClockPinState(0);
	for(int i=0;i<32;i++)
	{
		minorDelay();
		setClockPinState(1);
		internalDelayMs(12);
		temp=getDataPinState();
		ret|=temp<<i;
		minorDelay();
		setClockPinState(0);
		minorDelay();
	}
	 APP_DEBUG("\r\n");
	assignDataPinDirection(1,1);
	return ret;
}

/////////////////////////ARDUINO SECTION !!!!!!!!!!!!! -- DONT USE FOR QUECTEL----------------------------
//void setup()
//{
//	Serial.begin(115200);
//	Serial.println("START");
//	initializeZTIInterface();
//	/* add setup code here */
//
//}
//
//void loop()
//{
//u16 cntr=20,wait=0;
//  while(1)
//  {
//	  if(Serial.available()>0)
//	  {
//		  char c=Serial.read();
//		  if(c=='s')
//		  {
//			  wait=1;
//			  Serial.println("GIVING sleep COMMAND");
//			  ltoWConv.dataLong=readDATAFromBus(ENTER_SLEEP_MODE,cntr);
//		      Serial.print("RESP: ");
//			  Serial.print(ltoWConv.dataWord[0] & 0xFFFF);
//			  Serial.write(',');
//			  Serial.println(ltoWConv.dataWord[1] & 0x7FFF);
//			  delay(1000);
//		  }
//		  else if(c=='t')
//		  {
//			  cntr=Serial.parseInt();
//			  Serial.print("GIVING SLEEP TIME: ");
//			  Serial.println(cntr);
//			  delay(1000);
//		  }
//		  else if(c=='w')
//		  {
//			  Serial.println("CLR WAIT!");
//			  wait=0;
//		  }
//	  }
//	  if(wait==0)
//	  {
//	   ltoWConv.dataLong=readDATAFromBus(READ_DATA_FRAME,cntr);
//	   Serial.print("RESP: ");
//	   Serial.print(ltoWConv.dataWord[0] & 0xFFFF);
//	   Serial.write(',');
//	   Serial.println(ltoWConv.dataWord[1] & 0x7FFF);
//	  }
//  }
//  /* add main program code here */
//
//}
//////////////////////////////////////////////////////////////////
/*while(1)
{
if(Serial.available()>0)
{
c=Serial.read();
if(c=='b')
break;
else if(c=='o')
{
PORTC|=SCL_PIN;
Serial.println("ON");
}
else if(c=='f')
{
PORTC&=SCL_PIN_NEG;
Serial.println("OFF");
}
}
Serial.println(PINC,BIN);
delay(1000);
}*/

//---------------------------------------DEMO_CODE-------------------------------------------------
//#ifdef __CUSTOMER_CODE__
//
////#define REMOVE_PROGRAM_HANG // TO REMOVE PROGRAM HANG
//
//#include "defines.h"
//#include "ql_trace.h"
//#include "ql_system.h"
//#include "ql_timer.h"
//#include "HELPER_FUNCTIONS.h"
//#include "MC60_GPIO.h"
//#include "MC60_UART.h"
//#include "MC60_STARTUP_COMMONS.h"
//#include "MC60_GPS.h"
//#include "MC60_GSM.h"
//#include "MC60_GPIO.h"
//#include "MC60_EXT_WDT.h"
//#include "ql_power.h"
//
//s32 gret;
//
//void setup()
//{
//	APP_DEBUG("SETUP IN TASK\r\n");
//	initializeZTIInterface();
//	//gpsPowerOn();
//	//smsTest();
//}
//
//void loop()
//{
//	static u32 pTme=0,cntr=0;
//	static u8 wait=0;
//	char c=0;
//	wdtReset();
//		  if(Serial.available(&Serial)>0)
//		  {
//			  char c=Serial.read(&Serial);
//			  if(c=='s')
//			  {
//				  wait=1;
//				  APP_DEBUG("GIVING sleep COMMAND\r\n");
//				  ltoWConv.dataLong=readDATAFromBus(ENTER_SLEEP_MODE,cntr);
//				  APP_DEBUG("RESP: %d, %d \r\n",(ltoWConv.dataWord[0] & 0xFFFF),(ltoWConv.dataWord[1] & 0x7FFF))
//				  delay(1000);
//				  Ql_PowerDown(1);
//			  }
//			  else if(c=='t')
//			  {
//				  cntr=parseInt(&Serial);
//				  APP_DEBUG("ENTERED SLEEP TIME: %d\r\n",cntr);
//				  delay(1000);
//			  }
//			  else if(c=='w')
//			  {
//				  APP_DEBUG("CLR WAIT!\r\n");
//				  wait=0;
//			  }
//			  else if(c=='y')
//			  {
//				  APP_DEBUG("SET WAIT!\r\n");
//				  				  wait=1;
//			  }
//		  }
//    if((millis()-pTme)>=1000)
//	{
//    pTme=millis();
//    if(wait==0)
//    		  {
//    		   ltoWConv.dataLong=readDATAFromBus(READ_DATA_FRAME,cntr);
//    		   APP_DEBUG("RESP: %d, %d , %d\r\n",(ltoWConv.dataWord[0] & 0xFFFF),(ltoWConv.dataWord[1] & 0x7FFF),ltoWConv.dataLong)
//    		  }
//	}
//
//
//}
//#endif
//

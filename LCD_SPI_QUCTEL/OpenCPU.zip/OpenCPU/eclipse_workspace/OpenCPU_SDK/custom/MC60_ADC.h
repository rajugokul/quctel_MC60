/*
 * MC60_ADC.h
 *
 *  Created on: 14-Oct-2019
 *      Author: Sriram
 */

#ifndef MC60_ADC_H_
#define MC60_ADC_H_
//----------------------------------------------INCLUDES----------------------------------------------
#include "ql_adc.h"
#include "ql_type.h"
#include "MC60_BTSGPIO.h"
//----------------------------------------------GLOBAL_VARIABLES--------------------------------------
static u32 ADC_CustomParam = 1;
Enum_PinName adcPin = PIN_ADC0;

//----------------------------------------------FUNCTIONS_PROTO----------------------------------------
void ADC_callback_handle(Enum_ADCPin adcPin, u32 adcValue, void *customParam);
void adcInit(void);
void adcSamplingStart();
void adcSamplingStop();
void adcProces();
//----------------------------------------------FUNCTIONS----------------------------------------
void ADC_callback_handle(Enum_ADCPin adcPin, u32 adcValue, void *customParam)
{
s32 ret;
if (PIN_ADC0==adcPin )
{
gpioData.adc1=adcValue;

//adcVal();
//if( *((s32*)customParam) >= 4)
//{
////Stop ADC0 sampling if developers do not need it.
//ret=Ql_ADC_Sampling(PIN_ADC0, 0);
//adcOff();
//}
}
*((s32*)customParam) +=1;
}

void adcInit()
{
	s32 ret;
	//Register ADC0 callback function.
	ret=Ql_ADC_Register(adcPin, ADC_callback_handle, (void * )&ADC_CustomParam);
	//Set the internal sampling times and the interval.
	ret=Ql_ADC_Init(adcPin, 5, 200);//So the ADC0 reports the ADC value at frequency of 1Hz.(5*200ms).
}

void adcSamplingStart()
{
	 // Start ADC sampling
	   // APP_DEBUG("<-- Start ADC sampling -->\r\n")
	    Ql_ADC_Sampling(adcPin, TRUE);

}

void adcSamplingStop()
{
// Stop  sampling ADC
Ql_ADC_Sampling(adcPin,FALSE);
}


//----------------------------------------DEMO_CODE---------------------------------------------------

//#ifdef __CUSTOMER_CODE__
//#include "MC60_UART.h"
//#include "MC60_ADC.h"
//#include "MC60_STARTUP_COMMONS.h"
//
//void adcVal()
//{
//APP_DEBUG("\r\nADC1 VAL 2: %d\r\n",gpioData.adc1);
//}
//
//void adcOff()
//{
//APP_DEBUG("\r\nADC off\r\n");
//}
//
//void proc_main_task(s32 TaskId)
//{
//    s32 ret;
//    ST_MSG msg;
//    bool keepGoing = TRUE;
//    s8 startUpDone=0;
//       serialRegInit(UART_PORT1);
//       serialBegin(UART_PORT1,115200);
//
//       APP_DEBUG("APP DEBUG OPEN UART 1\r\n");
//
//    while (keepGoing)
//    {
//         Ql_OS_GetMessage(&msg);
//        switch(msg.message)
//        {
//        case MSG_ID_RIL_READY:
//                    	rilInit();
//                     	initGpio();
//                     	API_TEST_adc();
//                    	APP_DEBUG("\r\n<--System  Init OK -->\r\n");
//                        break;
//        default:
//        	 startUpDone=1;
//        	 APP_DEBUG("\r\n<--while loop -->\r\n");
//            break;
//        }
//        if(startUpDone==1)
//                {
//        	APP_DEBUG("\r\n<--main loop -->\r\n");
//                	//processIo();
//                }
//
//    }
//    APP_DEBUG("\r\n<--Pro main -->\r\n");
//}
//
//#endif // __CUSTOMER_CODE__




#endif /* MC60_ADC_H_ */

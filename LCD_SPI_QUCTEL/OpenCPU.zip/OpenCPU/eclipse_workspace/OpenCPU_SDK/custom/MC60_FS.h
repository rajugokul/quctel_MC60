/*
 * MC60_FS.h
 *
 *  Created on: 17-Oct-2019
 *      Author: vj
 */

#ifndef MC60_FS_H_
#define MC60_FS_H_
//-----------------------------------INCLUDES----------------------------------------------------------
#include "ql_fs.h"
#include "string.h"
#include "MC60_UART.h"

///----------------------------------GLOBAL_VARIABLES---------------------------------------------------------------
#define MEMORY_TYPE  1
#define FILE_NAME "BTS_TEST.txt"
#define NEW_FILE_NAME "file.txt"
#define DIR_NAME "DIR\\"
#define LPPATH "\\*"
#define LPPATH2 "\\DIR\\*"
#define XDELETE_PATH "\\"
#define WRITE_DATA1 "zuppa file system testing file1"
#define WRITE_DATA2 "file system2 testing "
#define OFFSET 0

//FILE HANDLE
s32 filehandle;
//-----------------------------------FUNCTIONS_PROTO---------------------------------------------------------

void freeSpace();
void totalSpace();
void format();
void crateFile(u8 *str);
void fileWrite();
void fileRead();
void getFileSize();
void checkFileExist();
void fileClose();
void fileDelete();
void fileTeast();
//-----------------------------------FUNCTIONS---------------------------------------------------------

void freeSpace()
{
	s64 size;
	//Get the amount of free space on flash or SD card.
	size=Ql_FS_GetFreeSpace(MEMORY_TYPE);
	APP_DEBUG("Ql_FS_GetFreeSpace()=%lld,type =%d\r\n",size,MEMORY_TYPE);
}

void totalSpace()
{
	s64 size;
	//Get the amount of total space on flash or SD card.
	size=Ql_FS_GetTotalSpace(MEMORY_TYPE);
	APP_DEBUG("Ql_FS_GetTotalSpace()=%lld,type =%d\r\n",size,MEMORY_TYPE);
}

void format()
{
	s32 ret;
	//Format the UFS.
	ret=Ql_FS_Format(MEMORY_TYPE);
	APP_DEBUG("Ql_FS_Format()=%d type =%d\r\n",ret,MEMORY_TYPE);
}

void crateFile(u8 *str)
{
	s32 ret;
	//Create a file
	ret=Ql_FS_Open(str, QL_FS_READ_WRITE|QL_FS_CREATE);
	if(ret >= QL_RET_OK)
	{
	filehandle = ret;
	}
	APP_DEBUG("Ql_FS_OpenCreate(%s,%08x)=%d\r\n",str,
	QL_FS_READ_WRITE|QL_FS_CREATE, ret);
}


void fileWrite()
{
	s32 ret;
	u32 writeedlen;
	//Write "1234567890" to file.
	ret=Ql_FS_Write(filehandle, WRITE_DATA1, Ql_strlen(WRITE_DATA1), &writeedlen);
	APP_DEBUG("Ql_FS_Write()=%d: writeedlen=%d\r\n",ret, writeedlen);
	//Write data remaining in the file buffer to the file.
	APP_DEBUG("filehandle write data=%d",filehandle);
	Ql_FS_Flush(filehandle);

}
void fileWrite1()
{
	s32 ret;
	u32 writeedlen;
	//Write "1234567890" to file.
	ret=Ql_FS_Write(filehandle, WRITE_DATA2, Ql_strlen(WRITE_DATA2), &writeedlen);
	APP_DEBUG("Ql_FS_Write()=%d: writeedlen=%d\r\n",ret, writeedlen);
	//Write data remaining in the file buffer to the file.
	APP_DEBUG("filehandle write data=%d",filehandle);
	Ql_FS_Flush(filehandle);

}

void fileRead()
{
	s32 ret;
	u8  strBuf[100];
	u32 readedlen;
	//Move the file pointer to the starting position.
	ret=Ql_FS_Seek(filehandle, OFFSET , QL_FS_FILE_BEGIN);
	APP_DEBUG("Ql_FS_Seek()=%d: offset=%d\r\n",ret, OFFSET);
	//Read data from file.
	Ql_memset(strBuf,0,100);
	ret = Ql_FS_Read(filehandle, strBuf, 100, &readedlen);
	APP_DEBUG("Ql_FS_Read()=%d: readedlen=%d, strBuf=%s\r\n",ret, readedlen, strBuf);
	APP_DEBUG("filehandle read data=%d",filehandle);
}

void getFileSize()
{
s32 filesize;
//Get the size of the file.
filesize=Ql_FS_GetSize(FILE_NAME);
APP_DEBUG((char*)("Ql_FS_GetSize(%s), filesize=%d\r\n"), FILE_NAME, filesize);
}

void checkFileExist()
{
	s32 ret;
	//Check whether the file exists or not.
	ret=Ql_FS_Check(FILE_NAME);
	APP_DEBUG("Ql_FS_Check(%s)=%d\r\n", FILE_NAME, ret);
}
void fileClose()
{
	//Close the file.
	Ql_FS_Close(filehandle);
	APP_DEBUG("\r\nfile close done\r\n");
}

void fileDelete(file1)
{
	s32 ret;
	//Delete the file file.txt.
	ret=Ql_FS_Delete(file1);
	APP_DEBUG("Ql_FS_Delete(%s)=%d\r\n", FILE_NAME, ret);
}

void fileTeast()
{
	 freeSpace();
	 totalSpace();
	 format();
	 crateFile(FILE_NAME);
	 fileWrite();
	 fileRead();
	 getFileSize();
     checkFileExist();
	 fileClose();
	 fileDelete();
}

#endif
//----------------------------------------------TEST_PROGRAM------------------------------------------

//void API_TEST_File(void)
//{
//s32 ret;
//s64 size;
//s32 filehandle, findfile;
//u32 writeedlen, readedlen ;
//u8 strBuf[100];
//s32 position;
//s32 filesize;
//bool isdir;
//
//APP_DEBUG("\r\nfile test Start\r\n");
////Get the amount of free space on flash or SD card.
//size=Ql_FS_GetFreeSpace(MEMORY_TYPE);
//APP_DEBUG("Ql_FS_GetFreeSpace()=%lld,type =%d\r\n",size,MEMORY_TYPE);
////Get the amount of total space on flash or SD card.
//size=Ql_FS_GetTotalSpace(MEMORY_TYPE);
//APP_DEBUG("Ql_FS_GetTotalSpace()=%lld,type =%d\r\n",size,MEMORY_TYPE);
////Format the UFS.
//ret=Ql_FS_Format(MEMORY_TYPE);
//APP_DEBUG("Ql_FS_Format()=%d type =%d\r\n",ret,MEMORY_TYPE);
////Create a file test.txt.
//ret=Ql_FS_Open(FILE_NAME, QL_FS_READ_WRITE|QL_FS_CREATE);
//if(ret >= QL_RET_OK)
//{
//filehandle = ret;
//}
//APP_DEBUG("Ql_FS_OpenCreate(%s,%08x)=%d\r\n",FILE_NAME,
//QL_FS_READ_WRITE|QL_FS_CREATE, ret);
//
////Write "1234567890" to file.
//ret=Ql_FS_Write(filehandle, WRITE_DATA, Ql_strlen(WRITE_DATA), &writeedlen);
//APP_DEBUG("Ql_FS_Write()=%d: writeedlen=%d\r\n",ret, writeedlen);
////Write data remaining in the file buffer to the file.
//Ql_FS_Flush(filehandle);
////Move the file pointer to the starting position.
//ret=Ql_FS_Seek(filehandle, OFFSET , QL_FS_FILE_BEGIN);
//APP_DEBUG("Ql_FS_Seek()=%d: offset=%d\r\n",ret, OFFSET);
////Read data from file.
//Ql_memset(strBuf,0,100);
//ret = Ql_FS_Read(filehandle, strBuf, 100, &readedlen);
//APP_DEBUG("Ql_FS_Read()=%d: readedlen=%d, strBuf=%s\r\n",ret, readedlen, strBuf);
////Move the file pointer to the starting position.
//ret=Ql_FS_Seek(filehandle, OFFSET , QL_FS_FILE_BEGIN);
//APP_DEBUG("Ql_FS_Seek()=%d: offset=%d\r\n",ret, OFFSET);
////Truncate the file to zero length.
//ret=Ql_FS_Truncate(filehandle);
//APP_DEBUG("Ql_FS_Truncate()=%d\r\n",ret);
////Read data from file.
//Ql_memset(strBuf,0,100);
//ret=Ql_FS_Read(filehandle, strBuf, 100, &readedlen);
//APP_DEBUG("Ql_FS_Read()=%d: readedlen=%d, strBuf=%s\r\n",ret, readedlen, strBuf);
////Get the position of the file pointer.
//position=Ql_FS_GetFilePosition(filehandle);
//APP_DEBUG("Ql_FS_GetFilePosition(): Position=%d\r\n",position);
////Close the file.
//Ql_FS_Close(filehandle);
//filehandle=-1;
//APP_DEBUG("Ql_FS_Close()\r\n");
////Get the size of the file.
//filesize=Ql_FS_GetSize(FILE_NAME);
//APP_DEBUG((char*)("Ql_FS_GetSize(%s), filesize=%d\r\n"), FILE_NAME, filesize);
////Check whether the file exists or not.
//ret=Ql_FS_Check(FILE_NAME);
//APP_DEBUG("Ql_FS_Check(%s)=%d\r\n", FILE_NAME, ret);
////Rename the file name from "test.txt" to "file.txt".
//ret=Ql_FS_Rename(FILE_NAME, NEW_FILE_NAME);
//APP_DEBUG("Ql_FS_Rename(\"%s\",\"%s\")=%d\r\n", FILE_NAME, NEW_FILE_NAME, ret);
////Delete the file file.txt.
//ret=Ql_FS_Delete(NEW_FILE_NAME);
//APP_DEBUG("Ql_FS_Delete(%s)=%d\r\n", NEW_FILE_NAME, ret);
////Create a file test.txt.
//ret=Ql_FS_Open(FILE_NAME, QL_FS_READ_WRITE|QL_FS_CREATE);
//if(ret >=QL_RET_OK)
//{
//filehandle=ret;
//}
//APP_DEBUG("Ql_FS_Open Create (%s,%08x)=%d\r\n", FILE_NAME,
//QL_FS_READ_WRITE|QL_FS_CREATE, ret);
////Write "1234567890" to file.
//ret=Ql_FS_Write(filehandle, WRITE_DATA, Ql_strlen(WRITE_DATA), &writeedlen);
//APP_DEBUG("Ql_FS_Write()=%d: writeedlen=%d\r\n",ret, writeedlen);
////Close the file.
//Ql_FS_Close(filehandle);
//filehandle=-1;
//APP_DEBUG("Ql_FS_Close()\r\n");
////Create a directory.
//ret=Ql_FS_CreateDir(DIR_NAME);
//APP_DEBUG("Ql_FS_CreateDir(%s)=%d\r\n", DIR_NAME, ret);
////Check whether the directory exists or not.
//ret=Ql_FS_CheckDir(DIR_NAME);
//APP_DEBUG("Ql_FS_CheckDir(%s)=%d\r\n", DIR_NAME, ret);
////Delete the directory.
//ret=Ql_FS_DeleteDir(DIR_NAME);
//APP_DEBUG("Ql_FS_DeleteDir(%s)=%d\r\n", DIR_NAME, ret);
////Create a directory.
//ret=Ql_FS_CreateDir(DIR_NAME);
//APP_DEBUG("Ql_FS_CreateDir(%s)=%d\r\n", DIR_NAME, ret);
////List all files and directories under the root of the UFS.
//Ql_memset(strBuf,0,100);
//findfile=Ql_FS_FindFirst(LPPATH, strBuf, 100, &filesize, &isdir);
//APP_DEBUG("\r\nLater:strBuf=[%s]",strBuf);
//if(findfile < 0)
//{
//APP_DEBUG("Failed Ql_FS_FindFirst(%s)=%d\r\n", LPPATH, findfile);
//}else{
//APP_DEBUG("Sueecss Ql_FS_FindFirst(%s)\r\n", LPPATH);
//}
//ret=findfile;
//while(ret >=0)
//{
//APP_DEBUG("filesize(%d),isdir(%d),Name(%s)\r\n", filesize, isdir, strBuf);
//ret=Ql_FS_FindNext(findfile, strBuf, 100, &filesize, &isdir);
//if(ret !=QL_RET_OK)
//break;
//}
//Ql_FS_FindClose(findfile);
////Copy the file test.txt to the directory DIR.
//ret=Ql_FS_XMove(FILE_NAME, DIR_NAME, QL_FS_MOVE_COPY);
//APP_DEBUG("Ql_FS_XMove(%s.%s,%x)=%d\r\n", FILE_NAME, DIR_NAME,
//QL_FS_MOVE_COPY, ret);
////List all files and directories in the directory DIR.
//Ql_memset(strBuf,0,100);
//findfile=Ql_FS_FindFirst(LPPATH2, strBuf, 100, &filesize, &isdir);
//APP_DEBUG("\r\nLater:strBuf=[%s]",strBuf);
//if(findfile<0)
//{
//APP_DEBUG("Failed Ql_FS_FindFirst(%s)=%d\r\n", LPPATH2, findfile);
//}else{
//APP_DEBUG("Sueecss Ql_FS_FindFirst(%s)\r\n", LPPATH2);
//}
//ret=findfile;
//while(ret>=0)
//{
//APP_DEBUG("filesize(%d),isdir(%d),Name(%s)\r\n", filesize, isdir, strBuf);
//ret=Ql_FS_FindNext(findfile, strBuf, 100, &filesize, &isdir);
//if(ret !=QL_RET_OK)
//break;
//}
//Ql_FS_FindClose(findfile);
////Delete all files and directories under the root of the UFS by recursive way.
//ret=Ql_FS_XDelete(XDELETE_PATH,QL_FS_FILE_TYPE
//|QL_FS_DIR_TYPE|QL_FS_RECURSIVE_TYPE);
//APP_DEBUG("\r\nQl_FS_XDelete(%s,%x)=%d\r\n",XDELETE_PATH,
//QL_FS_RECURSIVE_TYPE, ret);
//Ql_memset(strBuf,0,100);
//findfile=Ql_FS_FindFirst(LPPATH, strBuf, 100, &filesize, &isdir);
//APP_DEBUG("Later:strBuf=[%s]",strBuf);
//if(findfile < 0)
//{
//APP_DEBUG("Failed Ql_FS_FindFirst(%s)=%d\r\n", LPPATH, findfile);
//}else{
//APP_DEBUG("Sueecss Ql_FS_FindFirst(%s)\r\n", LPPATH);
//}
//ret=findfile;
//while(ret>=0)
//{
//APP_DEBUG("filesize(%d),isdir(%d),Name(%s)\r\n", filesize, isdir, strBuf);
//ret=Ql_FS_FindNext(findfile, strBuf, 100, &filesize, &isdir);
//if(ret !=QL_RET_OK)
//break;
//}
//Ql_FS_FindClose(findfile);
//APP_DEBUG("\r\nfile test end\r\n");
//}

//#endif /* MC60_FS_H_ */

//------------------------------------------DEMO_CODE-------------------------------------------------
////------------------------------------------MAIN-----------------------------------------------------
//#ifdef __CUSTOMER_CODE__
//#include "MC60_STARTUP_COMMONS.h"
//#include "MC60_UART.h"
//#include "MC60_FS.h"
//
////------------------------------------------FUNCTIONS------------------------------------------------
//void fileTeast()
//{
//	 freeSpace();
//	 totalSpace();
//	 format();
//	 crateFile();
//	 fileWrite();
//	 fileRead();
//	 getFileSize();
//     checkFileExist();
//	 fileClose();
//	 fileDelete();
//}
//
///******************************************************************************/
///*                              Main Code                                     */
///******************************************************************************/
//void proc_main_task(void)
//{
//    ST_MSG msg;
//    s32 ret = -1;
//u8 flag=0;
//
//    //	    // Register & open UART port
//    	    serialRegInit(UART_PORT1);
//    	    serialBegin(UART_PORT1,115200);
//    	    APP_DEBUG("\r\n<-- Uart 1 open -->\r\n");
//
//
//    while (TRUE)
//    {
//         Ql_OS_GetMessage(&msg);
//
//        switch(msg.message)
//        {
//        case 0:
//
//            break;
//        default:
//        	fileTeast();
//            break;
//        }
//
//    }
//
//}
//#endif // __EXAMPLE_FILESYSTEM__




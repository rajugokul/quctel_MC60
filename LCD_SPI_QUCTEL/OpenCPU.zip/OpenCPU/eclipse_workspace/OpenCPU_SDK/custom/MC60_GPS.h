/*
 * MC60_GPS.h
 *
 *  Created on: 04-Oct-2019
 *      Author: Sriram
 */

#ifndef MC60_GPS_H_
#define MC60_GPS_H_
#include "ril.h"
#include "ril_util.h"
#include "ril_gps.h"
#include "minmea.h"
#include "ql_error.h"
#include "ql_trace.h"
#include "MC60_UART.h"
#include "MC60_delay.h"
//--------------------------------------------------GOLOBAL_VARIABLES----------------------------------------
u8 gpsBuff[1000];
s32 gpsRet;
u8 nemaFlag=0;


const char GPS_STRINGS[10][21]={
"MINMEA_INVALID",
"MINMEA_UNKNOWN",
"MINMEA_SENTENCE_RMC",
"MINMEA_SENTENCE_GGA",
"MINMEA_SENTENCE_GSA",
"MINMEA_SENTENCE_GLL",
"MINMEA_SENTENCE_GST", //NOT PRESENT IN MC60
"MINMEA_SENTENCE_GSV",
"MINMEA_SENTENCE_VTG",
"MINMEA_SENTENCE_ZDA",
};

struct date_srt {
int day;
int month;
int year;
};

struct time_srt {
int hours;
int minutes;
int seconds;
int microseconds;
};

typedef struct GpsData
{
u32   latitude;
int32_t   longitude;
int32_t   AgpsLatitude;
int32_t   AgpsLongitude;
uint16_t  agpsAccuracy;
struct time_srt timeUTC;
struct date_srt   dateUTC;
float     speed;              //SOG
float     acceleration;       //no
float     pSpeed;             //no
uint32_t  pSampleTime;        //no
float     heading;           //COG
float     spdAcc;            //GST STRING
float     altitudeMSL;
float     gpsAccuracyM;      //HDOP*1.5
float   HDOP,PDOP;           //uint8_t
int     sats;               //SVS //uint8_t
bool    gpsLck;             //GVTG A-GPS LOCK
// process vars
float     gpsToImuAccelFactor;  //no
uint32_t  frameCounter;         //to do JUST INCREMENT
bool      gpsConn;              //PUT IT IN DEFAULT STATEMENT
bool      fstConn;              //no
};
struct GpsData gpsData;

//-------------------------------------------------FUNTIONS_PROTO----------------------------------------
void gpsATCmd(u8 *item);
u8 gpsRead(u8 *item,u8 *gpsBuff);
void gpsPowerOn();
void gpsPowerOff();
void gpsRMC();
void gpsGGA();
void gpsGSA();
void gpsVTG();
void gpsReadAll();
void test();
void stringRead();
//--------------------------------------------------FUNTIONS----------------------------------------

void gpsATCmd(u8 *item)

{
Ql_RIL_SendATCmd(item,sizeof(item), NULL, NULL, 0);

}

u8 gpsRead(u8 *item,u8 *gpsBuff)
{
Ql_memset(gpsBuff,0,sizeof(gpsBuff));
return RIL_GPS_Read(item,gpsBuff);
}

void gpsPowerOn()
{
gpsATCmd("AT+QGNSSC=1");
delay(5000);
}

void gpsPowerOff()
{
gpsATCmd("AT+QGNSSC=0");
delay(1000);
}

void gpsRMC()
{
u8 stringPos=0;
gpsRet = gpsRead("RMC",gpsBuff);
for(u8 i=0;i<255;i++)
{
if(gpsBuff[i]=='$')
{
stringPos=i;
}
if(stringPos>0)
{
gpsBuff[i-stringPos]=gpsBuff[i];
gpsBuff[i]='\0';
}
}
u8 type=minmea_sentence_id(gpsBuff, false);
switch (type) {
case MINMEA_SENTENCE_RMC: {

	gpsData.gpsConn=1; //if GPS string present

struct minmea_sentence_rmc frame;
if (minmea_parse_rmc(&frame, gpsBuff)) {

if(frame.latitude.value!=0)
{
//LATITUDE & LONGITITUDE
gpsData.latitude=minmea_tocoord(&frame.latitude)*10000000;
gpsData.longitude=minmea_tocoord(&frame.longitude)*10000000;
//COG-course over ground
gpsData.heading=minmea_tofloat(&frame.course);
//DATE
gpsData.dateUTC.day= frame.date.day;
gpsData.dateUTC.month= frame.date.month;
gpsData.dateUTC.year= frame.date.year;
//TIME
gpsData.timeUTC.hours= frame.time.hours;
gpsData.timeUTC.minutes= frame.time.minutes;
gpsData.timeUTC.seconds= frame.time.seconds;
gpsData.timeUTC.microseconds= frame.time.microseconds;
}
else
{
gpsData.latitude=0;
gpsData.longitude=0;
gpsData.dateUTC.day=0;
gpsData.dateUTC.month=0;
gpsData.dateUTC.year=0;
gpsData.timeUTC.hours=0;
gpsData.timeUTC.minutes=0;
gpsData.timeUTC.seconds=0;
gpsData.timeUTC.microseconds=0;
gpsData.heading=0;
}
}
else
{

}
};break;
default:
gpsData.latitude=0;
gpsData.longitude=0;
gpsData.dateUTC.day=0;
gpsData.dateUTC.month=0;
gpsData.dateUTC.year=0;
gpsData.timeUTC.hours=0;
gpsData.timeUTC.minutes=0;
gpsData.timeUTC.seconds=0;
gpsData.timeUTC.microseconds=0;
gpsData.heading=0;
gpsData.gpsConn=0;
;break;
}
//Ql_Sleep(10);
}

void gpsGGA()
{
u8 stringPos=0;
gpsRet = gpsRead("GGA",gpsBuff);
for(u8 i=0;i<255;i++)
{
if(gpsBuff[i]=='$')
{
stringPos=i;
}
if(stringPos>0)
{
gpsBuff[i-stringPos]=gpsBuff[i];
gpsBuff[i]='\0';
}
}
u8 type=minmea_sentence_id(gpsBuff, false);
switch (type) {
case MINMEA_SENTENCE_GGA: {

struct minmea_sentence_gga frame;
if (minmea_parse_gga(&frame, gpsBuff)) {

if(frame.altitude.value!=0)
{
gpsData.altitudeMSL=minmea_tofloat(&frame.altitude);
gpsData.sats=frame.satellites_tracked;
}
else
{
gpsData.altitudeMSL=0;
gpsData.sats=0;
}
}
else
{
}
};break;
default:
gpsData.altitudeMSL=0;
gpsData.sats=0;
;break;
}
//Ql_Sleep(10);
}

void gpsGSA()
{
u8 stringPos=0;
gpsRet = gpsRead("GSA",gpsBuff);
for(u8 i=0;i<255;i++)
{
if(gpsBuff[i]=='$')
{
stringPos=i;
}
if(stringPos>0)
{
gpsBuff[i-stringPos]=gpsBuff[i];
gpsBuff[i]='\0';
}
}
u8 type=minmea_sentence_id(gpsBuff, false);
switch (type) {
case MINMEA_SENTENCE_GSA: {

struct minmea_sentence_gsa frame;
if (minmea_parse_gsa(&frame, gpsBuff)) {

if(frame.hdop.value!=0)
{
gpsData.HDOP=minmea_tofloat(&frame.hdop);
gpsData.PDOP=minmea_tofloat(&frame.pdop);
gpsData.gpsAccuracyM=gpsData.HDOP*1.5;
}
else
{
gpsData.HDOP=0;
gpsData.PDOP=0;
gpsData.gpsAccuracyM=0;
}
}
else
{
}
};break;
default:
gpsData.HDOP=0;
gpsData.PDOP=0;
gpsData.gpsAccuracyM=0;
;break;
}
//Ql_Sleep(10);
}

void gpsVTG()
{
u8 stringPos=0;
gpsRet = gpsRead("VTG",gpsBuff);
for(u8 i=0;i<255;i++)
{
if(gpsBuff[i]=='$')
{
stringPos=i;
}
if(stringPos>0)
{
gpsBuff[i-stringPos]=gpsBuff[i];
gpsBuff[i]='\0';
}
}
u8 type=minmea_sentence_id(gpsBuff, false);
switch (type) {
case MINMEA_SENTENCE_VTG: {

struct minmea_sentence_vtg frame;
if (minmea_parse_vtg(&frame, gpsBuff)) {
if(frame.faa_mode=='A'||frame.faa_mode=='D')
{
//SPEED
gpsData.speed=minmea_tofloat(&frame.speed_kph);
gpsData.gpsLck=1;
}
if(frame.faa_mode=='N')
{
gpsData.gpsLck=0;
gpsData.speed=0;
}
}
else
{
}
};break;
default:
gpsData.gpsLck=0;
gpsData.speed=0;
;break;
}
//Ql_Sleep(10);
}
void stringRead()
{
gpsRead("ALL",gpsBuff);
APP_DEBUG("%s",gpsBuff);
}

void gpsReadAll()
{
gpsRMC();
gpsGGA();
gpsGSA();
gpsVTG();
}

void test()
{
	APP_DEBUG("GPS LAT: %d , LONG: %d \r\n",gpsData.latitude,gpsData.longitude);
	APP_DEBUG("Date: %d-%d-%d \r\n",gpsData.dateUTC.day,gpsData.dateUTC.month,gpsData.dateUTC.year);
	APP_DEBUG("Time: %d-%d-%d-%d \r\n",gpsData.timeUTC.hours,gpsData.timeUTC.minutes,gpsData.timeUTC.seconds,gpsData.timeUTC.microseconds);
	APP_DEBUG("Heading: %f \r\n",gpsData.heading);
	APP_DEBUG("altitude: %f \r\n",gpsData.altitudeMSL);
	APP_DEBUG("HDOP: %f  \r\n",gpsData.HDOP);
	APP_DEBUG("PDOP: %f  \r\n",gpsData.PDOP);
	APP_DEBUG("gpsAccuracyM: %f  \r\n",gpsData.gpsAccuracyM);
	APP_DEBUG("sats: %d \r\n",gpsData.sats);
	APP_DEBUG("gpsLck: %d  \r\n",gpsData.gpsLck);
	APP_DEBUG("Speed(km/ph): %f \r\n", gpsData.speed);
	APP_DEBUG("gps connection: %d \r\n",gpsData.gpsConn);
}

//-----------------------------------------------------END--------------------------------------------


//--------------------------------------GPS_DEMO------------------------------------------------------
//#ifdef __CUSTOMER_CODE__
//#include "ril.h"
//#include "ril_util.h"
//#include "ql_type.h"
//#include "ql_trace.h"
//#include "ql_system.h"
//#include "ql_uart.h"
//#include "ql_stdlib.h"
//#include "ql_error.h"
//#include "ril_gps.h"
//#include "ql_gnss.h"
//#include "nema_pro.h"
//#include "MC60_GPS.h"
//#include "minmea.h"
//
//
//
//#define DEBUG_ENABLE 1
//#if DEBUG_ENABLE > 0
//#define DEBUG_PORT  UART_PORT1
//#define DBG_BUF_LEN   512
//static char DBG_BUFFER[DBG_BUF_LEN];
//#define APP_DEBUG(FORMAT,...) {\
//    Ql_memset(DBG_BUFFER, 0, DBG_BUF_LEN);\
//    Ql_sprintf(DBG_BUFFER,FORMAT,##__VA_ARGS__); \
//    if (UART_PORT2 == (DEBUG_PORT)) \
//    {\
//        Ql_Debug_Trace(DBG_BUFFER);\
//    } else {\
//        Ql_UART_Write((Enum_SerialPort)(DEBUG_PORT), (u8*)(DBG_BUFFER), Ql_strlen((const char *)(DBG_BUFFER)));\
//    }\
//}
//#else
//#define APP_DEBUG(FORMAT,...)
//#endif
//
//#define SERIAL_RX_BUFFER_LEN  2048
//static u8 m_RxBuf_Uart[SERIAL_RX_BUFFER_LEN];
//static void Callback_UART_Hdlr(Enum_SerialPort port, Enum_UARTEventType msg, bool level, void* param);
//static void Callback_GPS_CMD_Hdlr(char *str_URC);
//
////extern
//extern s32 Analyse_Command(u8* src_str,s32 symbol_num,u8 symbol, u8* dest_buf);
//
//
///************************************************************************/
///* The entrance for this example application                            */
///************************************************************************/
//
//void RMC_STRING()
//{
//APP_DEBUG("GPS LAT: %d , LONG: %d \r\n",gpsData.latitude,gpsData.longitude);
//APP_DEBUG("Date: %d-%d-%d \r\n",gpsData.dateUTC.day,gpsData.dateUTC.month,gpsData.dateUTC.year);
//APP_DEBUG("Time: %d-%d-%d-%d \r\n",gpsData.timeUTC.hours,gpsData.timeUTC.minutes,gpsData.timeUTC.seconds,gpsData.timeUTC.microseconds);
//APP_DEBUG("Heading: %f \r\n",gpsData.heading);
//APP_DEBUG("gps connection: %d \r\n",gpsData.gpsConn);
//}
//
//void GGA_STRING()
//{
//APP_DEBUG("altitude: %f \r\n",gpsData.altitudeMSL);
//APP_DEBUG("sats: %d \r\n",gpsData.sats);
//}
//
//void GSA_STRING()
//{
//APP_DEBUG("HDOP: %f  \r\n",gpsData.HDOP);
//APP_DEBUG("PDOP: %f  \r\n",gpsData.PDOP);
//APP_DEBUG("gpsAccuracyM: %f  \r\n",gpsData.gpsAccuracyM);
//}
//
//void VTG_STRING()
//{
//APP_DEBUG("gpsLck: %d  \r\n",gpsData.gpsLck);
//APP_DEBUG("Speed(km/ph): %f \r\n", gpsData.speed);
//}
//
//void test()
//{
//	APP_DEBUG("GPS LAT: %d , LONG: %d \r\n",gpsData.latitude,gpsData.longitude);
//	APP_DEBUG("Date: %d-%d-%d \r\n",gpsData.dateUTC.day,gpsData.dateUTC.month,gpsData.dateUTC.year);
//	APP_DEBUG("Time: %d-%d-%d-%d \r\n",gpsData.timeUTC.hours,gpsData.timeUTC.minutes,gpsData.timeUTC.seconds,gpsData.timeUTC.microseconds);
//	APP_DEBUG("Heading: %f \r\n",gpsData.heading);
//	APP_DEBUG("altitude: %f \r\n",gpsData.altitudeMSL);
//	APP_DEBUG("HDOP: %f  \r\n",gpsData.HDOP);
//	APP_DEBUG("PDOP: %f  \r\n",gpsData.PDOP);
//	APP_DEBUG("gpsAccuracyM: %f  \r\n",gpsData.gpsAccuracyM);
//	APP_DEBUG("sats: %d \r\n",gpsData.sats);
//	APP_DEBUG("gpsLck: %d  \r\n",gpsData.gpsLck);
//	APP_DEBUG("Speed(km/ph): %f \r\n", gpsData.speed);
//	APP_DEBUG("gps connection: %d \r\n",gpsData.gpsConn);
//}
//
//
//void proc_main_task(s32 taskId)
//{
//    s8 startUpDone=0;
//    s32 ret;
//    ST_MSG msg;
//
//
//    // Register & open UART port
//    ret = Ql_UART_Register(UART_PORT1, Callback_UART_Hdlr, NULL);
//    ret = Ql_UART_Open(UART_PORT1, 115200, FC_NONE);
//    APP_DEBUG("\r\n<-- OpenCPU: GPS Example -->\r\n");
//
//
//    // Start message loop of this task
//    while (1)
//    {
//    	if(startUpDone==0)
//        Ql_OS_GetMessage(&msg);
//
//        switch(msg.message)
//        {
//            case MSG_ID_RIL_READY:
//            	gpsInit();
//            	APP_DEBUG("\r\n<-- GPS Init OK -->\r\n");
//                break;
//
//            case MSG_ID_USER_START:
//
//                break;
//
//            default:
//            	 startUpDone=1;
//
//                break;
//        }
//        if(startUpDone==1)
//        {
////        	gpsRead("ALL",gpsBuff);
////        	APP_DEBUG("%s",gpsBuff);
//
//        	 gpsReadAll();
//		     test();
//        	Ql_Sleep(1000);
//        }
//    }
//}
//
//
//static s32 ReadSerialPort(Enum_SerialPort port, /*[out]*/u8* pBuffer, /*[in]*/u32 bufLen)
//{
//    s32 rdLen = 0;
//    s32 rdTotalLen = 0;
//    if (NULL == pBuffer || 0 == bufLen)
//    {
//        return -1;
//    }
//    Ql_memset(pBuffer, 0x0, bufLen);
//    while (1)
//    {
//        rdLen = Ql_UART_Read(port, pBuffer + rdTotalLen, bufLen - rdTotalLen);
//        if (rdLen <= 0)  // All data is read out, or Serial Port Error!
//        {
//            break;
//        }
//        rdTotalLen += rdLen;
//        // Continue to read...
//    }
//    if (rdLen < 0) // Serial Port Error!
//    {
//        APP_DEBUG("<--Fail to read from port[%d]-->\r\n", port);
//        return -99;
//    }
//    return rdTotalLen;
//}
//
//void Callback_GPS_CMD_Hdlr(char *str_URC)
//{
//	if(str_URC != NULL)
//	{
//		APP_DEBUG("%s", str_URC);
//	}
//}
//
//static void Callback_UART_Hdlr(Enum_SerialPort port, Enum_UARTEventType msg, bool level, void* param)
//{
//    s32 iRet = 0;
//    switch (msg)
//    {
//        case EVENT_UART_READY_TO_READ:
//        {
//            char* p = NULL;
//            s32 totalBytes = ReadSerialPort(port, m_RxBuf_Uart, sizeof(m_RxBuf_Uart));
//            if (totalBytes <= 0)
//            {
//                break;
//            }
//
//            //APP_DEBUG("command is : %s\r\n",m_RxBuf_Uart);
//
//            /* Power On GPS */
//			p = Ql_strstr(m_RxBuf_Uart, "GPSOpen");
//            if(p)
//            {
//                iRet = RIL_GPS_Open(1);
//                if(RIL_AT_SUCCESS != iRet)
//                {
//                    APP_DEBUG("Power on GPS fail, iRet = %d.\r\n", iRet);
//                    break;
//                }
//
//                APP_DEBUG("Power on GPS Successful.\r\n");
//                break;
//            }
//
//            /* Power Off GPS */
//            p = Ql_strstr(m_RxBuf_Uart, "GPSClose");
//            if(p)
//            {
//                iRet = RIL_GPS_Open(0);
//                if(RIL_AT_SUCCESS != iRet)
//                {
//                    APP_DEBUG("Power off GPS fail, iRet = %d.\r\n", iRet);
//                    break;
//                }
//
//                APP_DEBUG("Power off GPS Successful.\r\n");
//                break;
//            }
//
//            /* GPSRead=<item> */
//            p = Ql_strstr(m_RxBuf_Uart, "GPSRead=<");
//            if(p)
//            {
//                u8 rdBuff[1000];
//                u8 item[10] = {0};
//
//
//                Ql_memset(rdBuff,0,sizeof(rdBuff));
//                Ql_strncpy(item,m_RxBuf_Uart+10,3);
//                APP_DEBUG("GPS String: %s\r\n",item);
//                iRet = RIL_GPS_Read(item,rdBuff);
//                if(RIL_AT_SUCCESS != iRet)
//                {
//                    APP_DEBUG("Read %s information failed.\r\n",item);
//                    break;
//                }
//                APP_DEBUG("%s\r\n",rdBuff);
//                break;
//            }
//
//			/* GPSEPO=<status>*/
//            p = Ql_strstr(m_RxBuf_Uart, "GPSEPO");
//            if(p)
//            {
//				s8 status = 0;
//				u8 status_buf[8] = {0};
//				if (Analyse_Command(m_RxBuf_Uart, 1, '>', status_buf))
//				{
//					APP_DEBUG("<--Parameter I Error.-->\r\n");
//					break;
//				}
//				status = Ql_atoi(status_buf);
//
//				iRet = RIL_GPS_EPO_Enable(status);
//
//                if(RIL_AT_SUCCESS != iRet)
//                {
//                    APP_DEBUG("Set EPO status to %d fail, iRet = %d.\r\n", status, iRet);
//                    break;
//                }
//
//                APP_DEBUG("Set EPO status to %d successful, iRet = %d.\r\n", status, iRet);
//                break;
//            }
//
//			/* GPSAid */
//            p = Ql_strstr(m_RxBuf_Uart, "GPSAid");
//            if(p)
//            {
//				iRet = RIL_GPS_EPO_Aid();
//
//                if(RIL_AT_SUCCESS != iRet)
//                {
//                    APP_DEBUG("EPO aiding fail, iRet = %d.\r\n", iRet);
//                    break;
//                }
//
//                APP_DEBUG("EPO aiding successful, iRet = %d.\r\n", iRet);
//                break;
//            }
//
//			/* GPSCMD=<cmdType>,<cmdString> */
//            p = Ql_strstr(m_RxBuf_Uart, "GPSCMD=<");
//            if(p)
//            {
//                s8 type;
//				u8 cmd_buf[128] = {0};
//				u8 type_buf[8] = {0};
//				if (Analyse_Command(m_RxBuf_Uart, 1, '>', type_buf))
//				{
//					APP_DEBUG("<--Parameter I Error.-->\r\n");
//					break;
//				}
//				type = Ql_atoi(type_buf);
//                Ql_memset(cmd_buf,0,sizeof(cmd_buf));
//				if (Analyse_Command(m_RxBuf_Uart, 2, '>', cmd_buf))
//                {
//                    APP_DEBUG("<--Parameter II Error.-->\r\n");
//                    break;
//                }
//
//                iRet = RIL_GPS_CMD_Send(type, cmd_buf, Callback_GPS_CMD_Hdlr);
//
//                if(RIL_AT_SUCCESS != iRet)
//                {
//                    APP_DEBUG("Send command \"%s\" failed! iRet=%d.\r\n",cmd_buf, iRet);
//                    break;
//                }
//                break;
//            }
//
//            APP_DEBUG("Invalid command...\r\n");
//        }break;
//
//        case EVENT_UART_READY_TO_WRITE:
//        {
//            //...
//        }break;
//
//        default:
//        break;
//    }
//}
//
//#endif  //__EXAMPLE_ALARM__
#endif  //__EXAMPLE_ALARM__

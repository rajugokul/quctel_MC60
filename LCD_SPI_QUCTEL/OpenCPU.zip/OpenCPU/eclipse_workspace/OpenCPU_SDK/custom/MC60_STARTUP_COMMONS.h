/*
 * MC60_STARTUP_COMMONS.h
 *
 *  Created on: 11-Oct-2019
 *      Author: Sriram
 */

#ifndef MC60_STARTUP_COMMONS_H_
#define MC60_STARTUP_COMMONS_H_

//includes
#include "variables.h"
//#include "MC60_UART.h"



//main fcuntions

void preInitializationSetup()
{
	    timerManager.callBackLoopFunction=0;
	    timerManager.mainLoopCounts=0;
	    timerManager.maxWdtLimit=0;
	    timerManager.wdtLoopCounts=0;
	    initializeHardwareSerial();
	    Serial.begin(&Serial,MAIN_UART_BAUD_RATE);
	    Serial1.begin(&Serial1,DEBUG_UART_BAUD_RATE);
	    APP_DEBUG("\r\n<-- ZUPPA : ATS (Advanced Telematics System) -->\r\n");
	    wdtInit(WDT_20S);
}

void proc_main_task(s32 taskId)
{
    ST_MSG msg;
    u8 ret;
    preInitializationSetup();
      while(TRUE)
      {
      	 Ql_OS_GetMessage(&msg);
    	 switch (msg.message)
    	       	{
    	       	case MSG_ID_RIL_READY:
    	       	{
    	       	        Ql_RIL_Initialize(); // MUST call this function
//    	       	        APP_DEBUG("->\r\n RIL IS READY!!\r\n");
    	       	        setup();
//    	       	        APP_DEBUG("-> CALLING SETUP()!!\r\n");
    	       	        timerManager.callBackLoopFunction=1;
    	       	}
    	       	break;

    	       	case MSG_ID_RUN_APP_CODE:
    	       	{
    	       		loop();
    	       		if(Ql_Timer_Start(MAIN_LOOP_TIMER_ID,MAIN_LOOP_TIMER_INTERVAL,FALSE)<0)
    	       		{
    	       			APP_DEBUG("MAIN TIMER RESTART FAIL!!\r\n");
    	       		}
    	       	}
    	        break;
    	       	}
    	 Ql_Sleep(1);
      }
}

void Timer_handler(u32 timerId, void* param)
{
    *((s32*)param) +=1;
    switch(timerId)
    {
    case MAIN_LOOP_TIMER_ID:
    {
    if(timerManager.callBackLoopFunction==1)
    {
    Ql_OS_SendMessage(main_task_id,MSG_ID_RUN_APP_CODE,*((s32*)param), 5);
    }
    }
    ;break;

    case WATCH_DOG_TIMER_ID:
    if(timerManager.wdtLoopCounts>=timerManager.maxWdtLimit)
    {
    	timerManager.wdtLoopCounts=0;
    	resetSystem(0);
    }
    ;break;
    }
}
#endif /* MC60_STARTUP_COMMONS_H_ */

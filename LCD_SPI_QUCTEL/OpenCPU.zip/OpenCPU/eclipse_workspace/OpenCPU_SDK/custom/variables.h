/*
 * variables.h
 *
 *  Created on: 14-Oct-2019
 *      Author: admin
 */

#ifndef VARIABLES_H_
#define VARIABLES_H_
//------------VARIABLES----------------
struct TimerCounter
{
    s32 mainLoopCounts;
    s32 wdtLoopCounts;
    u16 maxWdtLimit;
    u8  callBackLoopFunction;
}timerManager;
//------------FUNCTIONS_PROTO----------
void preInitializationSetup();
void setup();
void loop();
static void Timer_handler(u32 timerId, void* param);

//-----------GLOBAL_FUNCTION_DECLARATIONS------------
u8 initializeTimer(u32 timerId,u32 interval,u32 *param,u8 autoRepeat)
{
	s8 ret=0;
	ret = Ql_Timer_Register(timerId, Timer_handler, param);
    if(ret <0)
    {
    APP_DEBUG("\r\n<--failed!!, Ql_Timer_Register: timer(%d) fail ,ret = %d -->\r\n",timerId,ret);
	}
	else
	{
//	APP_DEBUG("\r\n<--Register: timerId=%d, param = %d,ret = %d -->\r\n", timerId ,*param,ret);
	}
    if(ret>=0)
    {
    ret = Ql_Timer_Start(timerId,interval,autoRepeat);
    if(ret < 0)
    {
    APP_DEBUG("\r\n<--failed!! stack timer Ql_Timer_Start ret=%d-->\r\n",ret);
    }
    else
    {
//    APP_DEBUG("\r\n<--stack timer Ql_Timer_Start(ID=%d,Interval=%d,) autoRepeat=%d , ret=%d-->\r\n",timerId,interval,autoRepeat,ret);
    }
    }
    return (ret>=0);
}

void wdtInit(u16 wdtOption)
{
	u8 ret=0;
	timerManager.maxWdtLimit=wdtOption;
    initializeTimer(MAIN_LOOP_TIMER_ID,MAIN_LOOP_TIMER_INTERVAL,&timerManager.mainLoopCounts,FALSE);
    initializeTimer(WATCH_DOG_TIMER_ID,WATCH_DOG_TIMER_INTERVAL,&timerManager.wdtLoopCounts,TRUE);
}

void wdtReset()
{
	timerManager.wdtLoopCounts=0;
}
#endif /* VARIABLES_H_ */

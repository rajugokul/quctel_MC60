/*
 * MC60_delay.h
 *
 *  Created on: 11-Oct-2019
 *      Author: Sriram
 */

#ifndef MC60_DELAY_H_
#define MC60_DELAY_H_

/* Parameters:
*             msec:
*            The time interval for which execution is to
*            be suspended, in milliseconds.*/

void delay(u32 msec)
{
Ql_Sleep(msec);
}


/* Description:
*            This function resets the system.
*
* Parameters:
*            resetType:
*            must be 0.*/

void resetSystem(u8 resetType)
{
Ql_Reset(resetType);
}

/* Description:
*               This function returns the number of milliseconds
*               since the device booted.
*
* Parameters:
*               None
* Return:
*               Number of milliseconds*/

u64 millis()
{
	u64 ret;
	return ret=Ql_GetMsSincePwrOn();
}

#endif /* MC60_DELAY_H_ */

//-----------------------------------DEMO_CODE--------------------------------------------------------
//#ifdef __CUSTOMER_CODE__
//#include "MC60_STARTUP_COMMONS.h"
//#include "MC60_UART.h"
//#include "MC60_delay.h"
///************************************************************************/
///* The entrance for this example application                            */
///************************************************************************/
//
//void proc_main_task(s32 taskId)
//{
//    s8 startUpDone=0;
//    s32 ret;
//    ST_MSG msg;
//u64 millisRet;
//
//    // Register & open UART port
//    serialRegInit(UART_PORT1);
//    serialBegin(UART_PORT1,115200);
//    APP_DEBUG("\r\n<--UART 1 OPEN -->\r\n");
//
//
//    // Start message loop of this task
//    while (1)
//    {
//    	if(startUpDone==0)
//        Ql_OS_GetMessage(&msg);
//
//        switch(msg.message)
//        {
//            case MSG_ID_RIL_READY:
//            	rilInit();
//            	APP_DEBUG("\r\n<-- ril Init OK -->\r\n");
//           delay(1000);
//                break;
//
//            case MSG_ID_USER_START:
//
//                break;
//
//            default:
//            	 startUpDone=1;
//            	 millisRet=millis();
//            	 APP_DEBUG("\r\n<--default state-->\r\n");
//            	 APP_DEBUG("\r\n<--millis: %llu-->\r\n",millisRet);
//            	 delay(1000);
//                break;
//        }
//        if(startUpDone){
//        	 APP_DEBUG("\r\n<--while loop-->\r\n");
//        	 delay(1000);
//        }
//
//    }
//}
//
//#endif  //__EXAMPLE_ALARM__

/*
 * MC60_ADC.h
 *
 *  Created on: 14-Oct-2019
 *      Author: Sriram
 */

#ifndef MC60_ADC_H_
#define MC60_ADC_H_
//----------------------------------------------INCLUDES----------------------------------------------
#include "ql_adc.h"
#include "ql_type.h"

//----------------------------------------------GLOBAL_VARIABLES--------------------------------------
static u32 ADC_CustomParam = 1;
Enum_PinName adcPin = PIN_ADC0;
u32 adValue=0;
//----------------------------------------------FUNCTIONS_PROTO----------------------------------------
static void Callback_OnADCSampling(Enum_ADCPin adcPin, u32 adcValue, void *customParam);
void adcInit(void);
void adcSamplingStart();
void adcSamplingStop();
void adcProces();
//----------------------------------------------FUNCTIONS----------------------------------------
static void Callback_OnADCSampling(Enum_ADCPin adcPin, u32 adcValue, void *customParam)
{
   // APP_DEBUG("<-- Callback_OnADCSampling: sampling voltage(mV)=%d  times=%d -->\r\n", adcValue, *((s32*)customParam))
	*((s32*)customParam) += 1;
	gpioData.adc1=adcValue;
}


void adcInit(void)
{
    // Register callback foR ADC
   // APP_DEBUG("<-- Register callback for ADC -->\r\n")
    Ql_ADC_Register(adcPin, Callback_OnADCSampling, (void *)&ADC_CustomParam);
    // Initialize ADC (sampling count, sampling interval)
   // APP_DEBUG("<-- Initialize ADC (sampling count=5, sampling interval=200ms) -->\r\n")
    Ql_ADC_Init(adcPin, 5, 200);  //PINNAME_SIM2_DATA/ADC1
}

void adcSamplingStart()
{
	 // Start ADC sampling
	   // APP_DEBUG("<-- Start ADC sampling -->\r\n")
	    Ql_ADC_Sampling(adcPin, TRUE);

}

void adcSamplingStop()
{
// Stop  sampling ADC
Ql_ADC_Sampling(adcPin, FALSE);
}


void adcProces()
{
adcInit();
adcSamplingStart();
delay(5000);
}


#endif /* MC60_ADC_H_ */

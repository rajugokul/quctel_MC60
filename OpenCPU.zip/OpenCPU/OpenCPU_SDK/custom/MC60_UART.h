/*
 * MC60_UART.h
 *
 *  Created on: 19-Sep-2019
 *      Author: sriram
 */

#ifndef MC60_UART_H_
#define MC60_UART_H_
#include "ql_uart.h"
#include "ql_error.h"
#include "ql_trace.h"
#include "ql_stdlib.h"

//---------CUSTOM_UART--------------

//------------DEFINES-----------------
#define SIZE_OF_RX_BUFFER_AUX 1024
enum UART_POINTERS
{
	INVALID_IDX,
	SERIAL,
	SERIAL1,
	SERIAL2,
	SERIAL3,
	SERIAL4,
	SERIAL5,
	TOTAL_NO_OF_SERIAL
};
//-----------------------------QUECTEL_PRINTF_FUNTION---------------------------------------------------------
u8 OUTPUT_UART_CHANNEL=SERIAL;
#define DEBUG_PORT  UART_PORT1
#define DEBUG_PORT1 UART_PORT2
#define DEBUG_PORT2 UART_PORT3
#define DBG_BUF_LEN   512
static char DBG_BUFFER[DBG_BUF_LEN],DBG_BUFFER1[DBG_BUF_LEN],DBG_BUFFER2[DBG_BUF_LEN];
//------------------------------------------------------------------------------------------------------------
#define APP_DEBUG(FORMAT,...) {\
    Ql_memset(DBG_BUFFER, 0, DBG_BUF_LEN);\
    Ql_sprintf(DBG_BUFFER,FORMAT,##__VA_ARGS__); \
    if (UART_PORT2 == (DEBUG_PORT)) \
    {\
        Ql_Debug_Trace(DBG_BUFFER);\
    } else {\
        Ql_UART_Write((Enum_SerialPort)(DEBUG_PORT), (u8*)(DBG_BUFFER), Ql_strlen((const char *)(DBG_BUFFER)));\
    }\
}

#define APP_DEBUG1(FORMAT,...) {\
    Ql_memset(DBG_BUFFER1, 0, DBG_BUF_LEN);\
    Ql_sprintf(DBG_BUFFER1,FORMAT,##__VA_ARGS__); \
    if (UART_PORT2 == (DEBUG_PORT1)) \
    {\
        Ql_Debug_Trace(DBG_BUFFER1);\
    } else {\
        Ql_UART_Write((Enum_SerialPort)(DEBUG_PORT1), (u8*)(DBG_BUFFER1), Ql_strlen((const char *)(DBG_BUFFER1)));\
    }\
}

#define APP_DEBUG2(FORMAT,...) {\
    Ql_memset(DBG_BUFFER2, 0, DBG_BUF_LEN);\
    Ql_sprintf(DBG_BUFFER2,FORMAT,##__VA_ARGS__); \
    if (UART_PORT2 == (DEBUG_PORT2)) \
    {\
        Ql_Debug_Trace(DBG_BUFFER2);\
    } else {\
        Ql_UART_Write((Enum_SerialPort)(DEBUG_PORT2), (u8*)(DBG_BUFFER2), Ql_strlen((const char *)(DBG_BUFFER2)));\
    }\
}

//---------------VARIABLES--------------------------

struct HardwareSerial
{
	u8  SERIAL_IDX;
	u8  initPrint;
	u8  inputBufferAux[SIZE_OF_RX_BUFFER_AUX];
	u16 auxHead,auxTail,auxFull;
	u16 auxRemaining;
	u16 (*available)(volatile struct HardwareSerial*);
	void     (*begin)(volatile struct HardwareSerial*,u32 baud);
	u8  (*read)(volatile struct HardwareSerial*);
	void     (*outputSelect)(volatile struct HardwareSerial*);
	u8  (*popData)(void);
};
volatile struct HardwareSerial Serial,Serial1,Serial2;

//------------FUNCTION_DEFINES---------------
// POP DATA
u8 auxBufferPopSerial();
u8 auxBufferPopSerial1();
u8 auxBufferPopSerial2();
// SERIAL_EVENT
extern void serialEvent();
extern void serialEvent1();
extern void serialEvent2();
static void UART1_HANDLER(Enum_SerialPort port, Enum_UARTEventType msg, bool level, void* customizedPara);
static void UART2_HANDLER(Enum_SerialPort port, Enum_UARTEventType msg, bool level, void* customizedPara);
static void UART3_HANDLER(Enum_SerialPort port, Enum_UARTEventType msg, bool level, void* customizedPara);
// PUSH_DATA
inline u8 auxBufferDataPushSerial(u8 data);
inline u8 auxBufferDataPushSerial1(u8 data);
inline u8 auxBufferDataPushSerial2(u8 data);
// APP - DEFINES
u16 available(volatile struct HardwareSerial *Serial);
u8 read(volatile struct HardwareSerial *Serial);
void outputSelect(volatile struct HardwareSerial *Serial);
void serialBegin(Enum_SerialPort uartx,u32 baudRate);
void initializeHardwareSerial();

//------------FUNCTION_DECLARE---------------
u16 available(volatile struct HardwareSerial *Serial)
{
	//updateBufferFromUART(Serial);
	Serial->auxRemaining=(Serial->auxFull==0)?((Serial->auxHead<Serial->auxTail)?(SIZE_OF_RX_BUFFER_AUX-Serial->auxTail+Serial->auxHead):Serial->auxHead-Serial->auxTail):SIZE_OF_RX_BUFFER_AUX;
	return Serial->auxRemaining;
}

u8 read(volatile struct HardwareSerial *Serial)
{
	//updateBufferFromUART(Serial);
	return Serial->popData();
}

void outputSelect(volatile struct HardwareSerial *Serial)
{
	OUTPUT_UART_CHANNEL=Serial->SERIAL_IDX;
}

void serialBegin(Enum_SerialPort uartx,u32 baudRate)
{
	switch(uartx)
		{
		case UART_PORT1:
		Ql_UART_Register(UART_PORT1, UART1_HANDLER, NULL);
		Ql_UART_Open(UART_PORT1, baudRate, FC_NONE);
		break;

		case UART_PORT2:
		Ql_UART_Register(UART_PORT2, UART2_HANDLER, NULL);
		Ql_UART_Open(UART_PORT2, baudRate, FC_NONE);
		break;

		case UART_PORT3:
		Ql_UART_Register(UART_PORT3, UART3_HANDLER, NULL);
		Ql_UART_Open(UART_PORT3, baudRate, FC_NONE);
		break;

		default :
		// invalid port
		break;
		}
}

void begin(volatile struct HardwareSerial *Serial,u32 baud)
{
    switch(Serial->SERIAL_IDX)
    {
    case SERIAL:
    serialBegin(UART_PORT1,baud);
    ;break;

    case SERIAL1:
    serialBegin(UART_PORT2,baud);
    ;break;

    case SERIAL3:
    serialBegin(UART_PORT3,baud);
    ;break;
    }
}
void initializeHardwareSerial()
{
	u8 i=0;
	Serial.SERIAL_IDX=SERIAL;
	Serial.available=available;
	Serial.begin=begin;
	Serial.read=read;
	Serial.outputSelect=outputSelect;
	Serial.popData=auxBufferPopSerial;
	Serial.auxFull=0;
	Serial.auxHead=0;
	Serial.auxTail=0;
	Serial.auxRemaining=0;

	Serial1.SERIAL_IDX=SERIAL1;
	Serial1.available=available;
	Serial1.begin=begin;
	Serial1.read=read;
	Serial1.outputSelect=outputSelect;
	Serial1.popData=auxBufferPopSerial1;

	Serial2.SERIAL_IDX=SERIAL2;
	Serial2.available=available;
	Serial2.begin=begin;
	Serial2.read=read;
	Serial2.outputSelect=outputSelect;
	Serial2.popData=auxBufferPopSerial2;
}
inline u8 auxBufferDataPushSerial(u8 data)
{
	if((Serial.auxHead!=Serial.auxTail)||(Serial.auxFull==0))
		{
			Serial.inputBufferAux[Serial.auxHead]=data;
			Serial.auxHead++;
			(Serial.auxHead>=SIZE_OF_RX_BUFFER_AUX)?Serial.auxHead=0:1;
			(Serial.auxHead==Serial.auxTail)?(Serial.auxFull=1):1;
		}
	return 1;
}
inline u8 auxBufferDataPushSerial1(u8 data)
{
	if((Serial1.auxHead!=Serial1.auxTail)||(Serial1.auxFull==0))
		{
			Serial1.inputBufferAux[Serial1.auxHead]=data;
			Serial1.auxHead++;
			(Serial1.auxHead>=SIZE_OF_RX_BUFFER_AUX)?Serial1.auxHead=0:1;
			(Serial1.auxHead==Serial1.auxTail)?Serial1.auxFull=1:1;
		}
	return 1;
}
inline u8 auxBufferDataPushSerial2(u8 data)
{
	if((Serial2.auxHead!=Serial2.auxTail)||(Serial2.auxFull==0))
		{
			Serial2.inputBufferAux[Serial2.auxHead]=data;
			Serial2.auxHead++;
			(Serial2.auxHead>=SIZE_OF_RX_BUFFER_AUX)?Serial2.auxHead=0:1;
			(Serial2.auxHead==Serial1.auxTail)?Serial2.auxFull=1:1;
		}
	return 1;
}
u8 auxBufferPopSerial()
{
	u8 ret=0;
		if((Serial.auxHead!=Serial.auxTail)||(Serial.auxFull==1))
		{
			ret=Serial.inputBufferAux[Serial.auxTail];
			Serial.inputBufferAux[Serial.auxTail]=0;
			Serial.auxTail++;
			(Serial.auxTail>=SIZE_OF_RX_BUFFER_AUX)?Serial.auxTail=0:1;
			Serial.auxFull=0;
		}
	return ret;
}
u8 auxBufferPopSerial1()
{
	u8 ret=0;
		if((Serial1.auxHead!=Serial1.auxTail)||(Serial1.auxFull==1))
		{
			ret=Serial1.inputBufferAux[Serial1.auxTail];
			Serial1.inputBufferAux[Serial1.auxTail]=0;
			Serial1.auxTail++;
			(Serial1.auxTail>=SIZE_OF_RX_BUFFER_AUX)?Serial1.auxTail=0:1;
			Serial1.auxFull=0;
		}
	return ret;
}
u8 auxBufferPopSerial2()
{
	u8 ret=0;
		if((Serial2.auxHead!=Serial2.auxTail)||(Serial2.auxFull==1))
		{
			ret=Serial2.inputBufferAux[Serial2.auxTail];
			Serial2.inputBufferAux[Serial2.auxTail]=0;
			Serial2.auxTail++;
			(Serial2.auxTail>=SIZE_OF_RX_BUFFER_AUX)?Serial2.auxTail=0:1;
			Serial2.auxFull=0;
		}
	return ret;
}

//------ADDITIONAL HELPERS------------------------
void printHex(unsigned long n, u8 base)
{
  char buf[8 * sizeof(long) + 1]; // Assumes 8-bit chars plus zero byte.
  char *str = &buf[sizeof(buf) - 1];

  *str = '\0';

  // prevent crash if called with base == 1
  if (base < 2) base = 10;

  do {
    char c = n % base;
    n /= base;

    *--str = c < 10 ? c + '0' : c + 'A' - 10;
  } while(n);

  APP_DEBUG("%s",str);
}

u16 hextodec(char* hex)
{
	u16 decimal,j;
	u8 i,k,r;
	decimal = 0;
	for(i=0; i<4; i++)
	{

		if(hex[i]>='0' && hex[i]<='9')
		{
			r = hex[i] - 48;
		}
		else if(hex[i]>='a' && hex[i]<='f')
		{
			r = hex[i] - 97 + 10;
		}
		else if(hex[i]>='A' && hex[i]<='F')
		{
			r = hex[i] - 65 + 10;
		}
		else
		{
		decimal=0;
		break;
		}
		j=1;
		for(k=0;k<(3-i);k++)
        j*=16;
		decimal += (r * j);
	}
	return decimal;
}

u8 stringFind(char *strMain,char *findStr,int minLimit)
{
		u8 equ=0;
		u8 pntrFind=0,pntrMain=0;
		while(1)
		{
			if((strMain[pntrMain]!='\0')){
			if((strMain[pntrMain]==findStr[pntrFind])||(((char)((u8)strMain[pntrMain]+32))==findStr[pntrFind])||(((char)((u8)strMain[pntrMain]-32))==findStr[pntrFind]))
			{
				pntrFind++;
				if(findStr[pntrFind]=='\0')
				{
					equ=1;
					break;
				}
			}
			pntrMain++;
			if(pntrMain>36)
			break;
			}
			else
			break;
		}
		((pntrFind<minLimit)&&(minLimit>0))?equ=0:1;
		return equ;
}

u8 stringCompare(char *str1,char *str2)
{
	u8 equ=1;
	u8 pntr=0;
	while(1)
	{
		if((str1[pntr]!='\0')&&(str2[pntr]!='\0')){
		if(str1[pntr]==str2[pntr])
		{
			pntr++;
		}
		else
		{
			equ=0;
			break;
		}
		}
		else
		break;
	}
	return equ;
}
u16 readBytesUntil(volatile struct HardwareSerial *Serial,char *in,u16 size,char term,u8 checkForNoOnly)
{
	u32 pt=0;
	char c=0;
	u16 pntr=0;
	pt=millis();
	 Serial2.outputSelect(&Serial2);

	while((millis()-pt)<5400)
	{
		if(Serial->available(Serial)>0)
		{
			c=Serial->read(Serial);
		  Serial2.outputSelect(&Serial2);
			if(((checkForNoOnly==0)&&(c!=term))||((checkForNoOnly==1)&&((c>=48)&&(c<=57))))
			{
			in[pntr]=c;
			pntr++;
			if(pntr>=size)
				break;
		  }
			else
				break;
		}
	}
	return pntr;
}

u32 parseInt(volatile struct HardwareSerial *Serial)
{
	u32 ret=0;
  char c[18];
	if(readBytesUntil(Serial,c,18,',',1)>0)
	{
		ret=atoi(c);
	}
	return ret;
}



//--------------------HANDLERS---------------------
static void UART1_HANDLER(Enum_SerialPort port, Enum_UARTEventType msg, bool level, void* customizedPara)
{
	u8 c[512];
	volatile u16 len,i;
    if(msg==EVENT_UART_READY_TO_READ)
    {
    	len=Ql_UART_Read(UART_PORT1, c,512);
    	for(i=0;i<len;i++)
    	auxBufferDataPushSerial(c[i]);
    }
}
static void UART2_HANDLER(Enum_SerialPort port, Enum_UARTEventType msg, bool level, void* customizedPara)
{
	    u8 c[512];
		volatile u16 len,i;
	    if(msg==EVENT_UART_READY_TO_READ)
	    {
	    	len=Ql_UART_Read(UART_PORT2, c,512);
	    	for(i=0;i<len;i++)
	    	auxBufferDataPushSerial1(c[i]);
	    }
}
static void UART3_HANDLER(Enum_SerialPort port, Enum_UARTEventType msg, bool level, void* customizedPara)
{
	    u8 c[512];
		volatile u16 len,i;
	    if(msg==EVENT_UART_READY_TO_READ)
	    {
	    	len=Ql_UART_Read(UART_PORT3, c,512);
	    	for(i=0;i<len;i++)
	    	auxBufferDataPushSerial2(c[i]);
	    }
}

#endif /* MC60_UART_H_ */

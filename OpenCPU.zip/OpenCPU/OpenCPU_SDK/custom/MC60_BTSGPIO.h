/*
 * MC60_BTSGPIO.h
 *
 *  Created on: 16-Oct-2019
 *      Author: admin
 */

#ifndef MC60_BTSGPIO_H_
#define MC60_BTSGPIO_H_
/*
 * MC60_STARTUP_COMMONS.h
 *
 *  Created on: 11-Oct-2019
 *      Author: Sriram
 */

//-------------------------------------------------INCLUDES-------------------------------------------
#include "MC60_GPIO.h"
#include "MC60_UART.h"
#include "MC60_delay.h"
//------------------------------------------------FUNTIONS---------------------------------------------

void initGpio();
void processIo();
//------------------------------------------------FUNTIONS---------------------------------------------
typedef struct gpio
{
bool   input1;   //TILT SENSOR
bool   input2;   //TAMPER PIN  -->IO_2
bool   input3;   //PINNAME_PCM_OUT/SPI_MOSI//ADC2
bool   input4;   //PINNAME_SD_CMD
bool   input5;   //PINNAME_SD_CLK
bool   input6;   //PINNAME_SIM2_DATA
bool   output1;
bool   output2;
u32   adc1;
};
struct gpio gpioData;





void initGpio()
{
     	//INPUT
	    pinMode(D17,INPUT,LOW,PULLDOWN); //PINNAME_GPIO_1                 //TILT SENSOR -->IO_1
		pinMode(D15,INPUT,LOW,PULLDOWN); //PINNAME_SIM2_CLK               //TAMPER PIN  -->IO_2
	    pinMode(D9,INPUT,LOW,PULLDOWN);  //PINNAME_PCM_OUT/SPI_MOSI//ADC2
		pinMode(D10,INPUT,LOW,PULLDOWN); //PINNAME_SD_CMD
		pinMode(D11,INPUT,LOW,PULLDOWN); //PINNAME_SD_CLK
		pinMode(D13,INPUT,LOW,PULLDOWN); //PINNAME_SIM2_DATA


        //OUTPUT
	    pinMode(D19,OUTPUT,LOW,PINPULLSEL_DISABLE);//GPIO_PIN3
	    pinMode(D20,OUTPUT,LOW,PINPULLSEL_DISABLE);//GPIO_PIN4


}

void tiltTest()
{
APP_DEBUG("\r\n\r\n<--- PLEASE TILT THE BOARD WITHIN 5 SECONDS --->\r\n\r\n");
delay(5000);
gpioData.input1=digitalRead(D17);                                                 //TILT STATUS
}

void tamperTest()
{
APP_DEBUG("\r\n\r\n<--- PLEASE PRESS THE SWITCH WITHIN 5 SECONDS --->\r\n\r\n");
delay(5000);
gpioData.input2=digitalRead(D15);                                                //TAMPER STATUS
}

void ioTest()
{
	APP_DEBUG("\r\n\r\n<--- PLEASE GIVE INPUT VOLTAGE TO IO PINS WITHIN 5 SECONDS --->\r\n\r\n");
	delay(5000);
	gpioData.input3=digitalRead(D9);   //PINNAME_PCM_OUT/SPI_MOSI//ADC2
	gpioData.input4=digitalRead(D10);  //PINNAME_SD_CMD
	gpioData.input5=digitalRead(D11);  //PINNAME_SD_CLK
	gpioData.input6=digitalRead(D13);  //PINNAME_SIM2_DATA

	digitalWrite(D19,HIGH);  //GPIO_3
	digitalWrite(D20,HIGH);  //GPIO_4
	gpioData.output1=digitalRead(D19);
	gpioData.output2=digitalRead(D20);
}



void processIo()
{
	////read input/////
gpioData.input1=digitalRead(D10);
APP_DEBUG("\r\nGPIO VAL D1: %d\r\n",gpioData.input1);//PINNAME_SD_CMD

gpioData.input2=digitalRead(D11);
APP_DEBUG("\r\nGPIO VAL D2: %d\r\n",gpioData.input2);//PINNAME_SD_CLK

gpioData.input3=digitalRead(D13);
APP_DEBUG("\r\nGPIO VAL D3: %d\r\n",gpioData.input3);//PINNAME_SIM2_DATA

gpioData.input4=digitalRead(D17);
APP_DEBUG("\r\nGPIO VAL D4: %d\r\n",gpioData.input4);//PINNAME_GPIO_1

gpioData.input5=digitalRead(D15);
APP_DEBUG("\r\nGPIO VAL D5: %d\r\n",gpioData.input5);//PINNAME_SIM2_CLK,

APP_DEBUG("\r\nADC VAL 1: %d\r\n",gpioData.adc1);// ADC pin

//gpioData.adc2=digitalRead(D9);
//APP_DEBUG("\r\nADC VAL 2: %d\r\n",gpioData.adc2);//PINNAME_PCM_OUT/SPI_MOSI



if(gpioData.output1==1)
{
	digitalWrite(D19,HIGH);
    APP_DEBUG("\r\nD19 pin --->HIGH");
}
else
digitalWrite(D19,LOW);


if(gpioData.output2==1)
{
digitalWrite(D20,HIGH);
APP_DEBUG("\r\nD20 pin --->HIGH");
}
else
digitalWrite(D20,LOW);

delay(1000);
}


#endif /* MC60_BTSGPIO.h */

//-------------------------------------------DEMO_CODE------------------------------------------------
//#ifdef __CUSTOMER_CODE__
//#include "MC60_UART.h"
//#include "MC60_ADC.h"
//#include "MC60_STARTUP_COMMONS.h"
//
//
//void adcVal()
//{
//APP_DEBUG("\r\nADC VAL 1: %d\r\n",gpioData.adc1);
//delay(1000);
//}
//
//void adcOff()
//{
//APP_DEBUG("\r\nADC off\r\n");
//}
//
//
//
//void proc_main_task(s32 taskId)
//{
//	    s8 startUpDone=0;
//	    s32 ret;
//	    ST_MSG msg;
//
//
//	    // Register & open UART port
//	    serialRegInit(UART_PORT1);
//	    serialBegin(UART_PORT1,115200);
//	    APP_DEBUG("\r\n<-- Uart 1 open -->\r\n");
//
//
//
//	    // Start message loop of this task
//	    while (1)
//	    {
//	        Ql_OS_GetMessage(&msg);
//
//	        switch(msg.message)
//	        {
//	            case MSG_ID_RIL_READY:
//	            	rilInit();
//	            	initGpio();
//	            	adcInit();
//	            	APP_DEBUG("\r\n<-- Init OK -->\r\n");
//	                break;
//
//	            case MSG_ID_USER_START:
//	            	APP_DEBUG("\r\n<-- user start -->\r\n");
//	                break;
//
//	            default:
//	            	 startUpDone=1;
//	                break;
//	    }
//}
//}
//
//void proc_subtask1(s32 taskId)
//{
//	while(TRUE)
//	{
//		APP_DEBUG("--TASHK1--\r\n");
//		processIo();
//		adcSamplingStart();
//		delay(1000);
//	}
//}
//
//#endif // __CUSTOMER_CODE__

/*
 * MC60_AGPS.h
 *
 *  Created on: 10-Oct-2019
 *      Author: Sriram
 */

#ifndef MC60_AGPS_H_
#define MC60_AGPS_H_
//---------------------------INCLUDES-----------------------------------------------------------------
#include "ql_type.h"
#include "ril.h"
#include "ril_network.h"
#include "ril_location.h"
#include "ql_gprs.h"
#include "ql_stdlib.h"
#include "MC60_GPS.h"
//----------------------------GLOBAL_VARIABLES--------------------------------------------------------

/****************************************************************************
* Definition for APN
****************************************************************************/
#define APN      "CMNET\0"
#define USERID   ""
#define PASSWD   ""

s8 aGpsFlag=0;
//-----------------------------FUNTIONS_PROTO----------------------------------------------------------------

ST_LocInfo locinfo;
void aGpsInit(ST_MSG msg);
void aGpsData();
static void Location_Program(void);
void Callback_Location(s32 result, ST_LocInfo* loc_info);

//-----------------------------FUNTIONS----------------------------------------------------------------
void aGpsInit(ST_MSG msg)
{

    switch (msg.param1)
              {
              case URC_GPRS_NW_STATE_IND:
                  if (NW_STAT_REGISTERED == msg.param2 || NW_STAT_REGISTERED_ROAMING == msg.param2)
                  {
                      //APP_DEBUG("<-- Module has registered to GPRS network -->\r\n");

                      // Module has registered to GPRS network, and app may start to program with QuecLocator
                      Location_Program();
                  }else{
                     // APP_DEBUG("<-- GPRS network status:%d -->\r\n", msg.param2);
                      /* status: 0 = Not registered, module not currently search a new operator
                      *         2 = Not registered, but module is currently searching a new operator
                      *         3 = Registration denied
                      */
                  }
                  break;
              default:
                  //APP_DEBUG("<-- Other URC: type=%d\r\n", msg.param1);
                  break;
              }
}


void aGpsData()
{
//APP_DEBUG("<--user Module location: latitude=%d, longitude=%d -->\r\n", gpsData.AgpsLatitude,gpsData.AgpsLongitude);
Ql_Sleep(1000);
}

static void Location_Program(void)
{
	s32 ret;
	u8  pdpCntxtId;

	u8 location_mode = 0;
    u8 asynch = 0;
	ST_CellInfo GetLocation;
	GetLocation.cellId = 22243;
	GetLocation.lac = 21764;
	GetLocation.mnc = 01;
	GetLocation.mcc = 460;
	GetLocation.rssi = 0;
	GetLocation.timeAd = 0;

	// Set PDP context
	ret = Ql_GPRS_GetPDPContextId();
	//APP_DEBUG("<-- The PDP context id available is: %d (can be 0 or 1)-->\r\n", ret);
	if (ret >= 0)
	{
	    pdpCntxtId = (u8)ret;
	} else {
    	//APP_DEBUG("<-- Fail to get PDP context id, try to use PDP id(0) -->\r\n");
	    pdpCntxtId = 0;
	}

	ret = RIL_NW_SetGPRSContext(pdpCntxtId);
	//APP_DEBUG("<-- Set PDP context id to %d -->\r\n", pdpCntxtId);
	if (ret != RIL_AT_SUCCESS)
	{
	    //APP_DEBUG("<-- Ql_RIL_SendATCmd error  ret=%d-->\r\n",ret );
	}

	// Set APN
	ret = RIL_NW_SetAPN(1, APN, USERID, PASSWD);
	//APP_DEBUG("<-- Set APN -->\r\n");

    //PDP activated
    ret = RIL_NW_OpenPDPContext();
    if (ret == RIL_AT_SUCCESS)
	{
	    //APP_DEBUG("<--PDPContext activated ret=%d-->\r\n",ret );
	}

	// Request to get location
	//APP_DEBUG("<-- Getting module location... -->\r\n");
	if(location_mode==0)
	{
        if(asynch == 1)
        {
    		//APP_DEBUG("<--Ql_Getlocation-->\r\n");
    		ret = RIL_GetLocation(Callback_Location);
    		if(ret != RIL_AT_SUCCESS)
    		{
    			//APP_DEBUG("<-- Ql_Getlocation error  ret=%d-->\r\n",ret );
    		}
        }
        else if(asynch == 0)
        {
            ret = RIL_GetLocation_Ex(&locinfo);
    		if(ret == RIL_AT_SUCCESS)
    		{
    			//APP_DEBUG("<-- Getlocation succeed  ret=%d-->\r\n",ret );
                //APP_DEBUG("<--Module location: latitude=%f, longitude=%f -->\r\n", locinfo.latitude, locinfo.longitude);
                gpsData.AgpsLatitude=locinfo.latitude*10000000;
                gpsData.AgpsLongitude=locinfo.longitude*10000000;
    		}
        }
	}
	else if(location_mode==1)
	{
		//APP_DEBUG("<--Ql_GetlocationByCell-->\r\n");
		ret = RIL_GetLocationByCell(&GetLocation,Callback_Location);
		if(ret!=RIL_AT_SUCCESS)
		{
			//APP_DEBUG("<-- Ql_GetlocationByCell error  ret=%d-->\r\n",ret );
		}
	}
}

void Callback_Location(s32 result, ST_LocInfo* loc_info)
{
    //APP_DEBUG("\r\n<--result = %d ,Module location: latitude=%f, longitude=%f -->\r\n",result, loc_info->latitude, loc_info->longitude);
}

#endif /* MC60_AGPS_H_ */



//---------------------------------------------DEMO_PROGRAM-------------------------------------------
//#ifdef __CUSTOMER_CODE__
//#include "ql_type.h"
//#include "ql_trace.h"
//#include "ql_uart.h"
//#include "ql_stdlib.h"
//#include "ql_error.h"
//#include "MC60_AGPS.h"

//

//#define DEBUG_ENABLE 1
//#if DEBUG_ENABLE > 0
//#define DEBUG_PORT  UART_PORT1
//#define DBG_BUF_LEN   512
//static char DBG_BUFFER[DBG_BUF_LEN];
//#define APP_DEBUG(FORMAT,...) {\
//    Ql_memset(DBG_BUFFER, 0, DBG_BUF_LEN);\
//    Ql_sprintf(DBG_BUFFER,FORMAT,##__VA_ARGS__); \
//    if (UART_PORT2 == (DEBUG_PORT)) \
//    {\
//        Ql_Debug_Trace(DBG_BUFFER);\
//    } else {\
//        Ql_UART_Write((Enum_SerialPort)(DEBUG_PORT), (u8*)(DBG_BUFFER), Ql_strlen((const char *)(DBG_BUFFER)));\
//    }\
//}
//#else
//#define APP_DEBUG(FORMAT,...)
//#endif
//
//static void CallBack_UART_Hdlr(Enum_SerialPort port, Enum_UARTEventType msg, bool level, void* customizedPara)
//{
//
//}
//
//void aGpsDataRead()
//{
//APP_DEBUG("<--MC60 Module location: latitude=%d, longitude=%d -->\r\n", gpsData.AgpsLatitude,gpsData.AgpsLongitude);
//Ql_Sleep(1000);
//}
//
///************************************************************************/
///*                                                                      */
///* The entrance to application, which is called by bottom system.       */
///*                                                                      */
///************************************************************************/
//void proc_main_task(s32 taskId)
//{
//    s32 ret;
//    ST_MSG msg;
//
//    // Register & open UART port
//    ret = Ql_UART_Register(UART_PORT1, CallBack_UART_Hdlr, NULL);
//    if (ret < QL_RET_OK)
//    {
//        Ql_Debug_Trace("Fail to register serial port[%d], ret=%d\r\n", UART_PORT1, ret);
//    }
//    ret = Ql_UART_Open(UART_PORT1, 115200, FC_NONE);
//    if (ret < QL_RET_OK)
//    {
//        Ql_Debug_Trace("Fail to open serial port[%d], ret=%d\r\n", UART_PORT1, ret);
//    }
//
//
//    APP_DEBUG("\r\n<-- OpenCPU: Demo for Program Location -->\r\n");
//    while (TRUE)
//    {
//         Ql_OS_GetMessage(&msg);
//        switch(msg.message)
//        {
//            case MSG_ID_RIL_READY:
//                APP_DEBUG("<-- RIL is ready -->\r\n");
//                Ql_RIL_Initialize();
//                break;
//
//                // Handle URC messages.
//                // URC messages include "module init state", "CFUN state", "SIM card state(change)",
//                // "GSM network state(change)", "GPRS network state(change)" and other user customized URC.
//            case MSG_ID_URC_INDICATION:
//                switch (msg.param1)
//                {
//                    // URC for GPRS network state(change).
//                    // Application receives this URC message when GPRS network state changes, such as register to
//                    // GPRS network during booting, GSM drops down.
//                case URC_GPRS_NW_STATE_IND:
//                    if (NW_STAT_REGISTERED == msg.param2 || NW_STAT_REGISTERED_ROAMING == msg.param2)
//                    {
//                        APP_DEBUG("<-- Module has registered to GPRS network -->\r\n");
//
//                        // Module has registered to GPRS network, and app may start to program with QuecLocator
//                        Location_Program();
//                        aGpsDataRead();
//                    }else{
//                        APP_DEBUG("<-- GPRS network status:%d -->\r\n", msg.param2);
//                        /* status: 0 = Not registered, module not currently search a new operator
//                        *         2 = Not registered, but module is currently searching a new operator
//                        *         3 = Registration denied
//                        */
//                    }
//                    break;
//                default:
//                    APP_DEBUG("<-- agps case default\r\n");
//                    break;
//                }
//        default:
//        	 APP_DEBUG("<-- switch case default\r\n");
//            break;
//        }
//        APP_DEBUG("<-- while loop\r\n");
//    }
//    APP_DEBUG("<-- main loop\r\n");
//}
//#endif // __EXAMPLE_LOCATION__


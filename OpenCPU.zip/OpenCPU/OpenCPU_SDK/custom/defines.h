/*
 * defines.h
 *
 *  Created on: 14-Oct-2019
 *      Author: admin
 */

#ifndef DEFINES_H_
#define DEFINES_H_
//------------GSM_DEBUG--------------------
#define ECHO_GSM_COMMAND
//----------MAIN UART SETTINGS--------------
#define MAIN_UART_BAUD_RATE 115200
#define DEBUG_UART_BAUD_RATE 115200
//----------TIMER MANAGER-------------------
#define MAIN_LOOP_TIMER_ID 			(TIMER_ID_USER_START+2)
#define MAIN_LOOP_TIMER_INTERVAL	100 // 100 ms
#define WATCH_DOG_TIMER_ID          (TIMER_ID_USER_START+3)
#define WATCH_DOG_TIMER_INTERVAL    1000 // 1000ms
enum
{
	WDT_1S=1,
	WDT_2S,
	WDT_5S=5,
	WDT_8S=8,
	WDT_10S=10,
	WDT_12S=12,
	WDT_14S=14,
	WDT_16S=16,
	WDT_18S=18,
	WDT_20S=20,
	WDT_25S=25,
	WDT_30S=30,
	WDT_35S=35,
	WDT_40S=40,
	WDT_50S=50,
	WDT_60S=60,
};

#endif /* DEFINES_H_ */
